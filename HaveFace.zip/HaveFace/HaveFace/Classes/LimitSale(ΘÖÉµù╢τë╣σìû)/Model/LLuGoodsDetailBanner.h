//
//  LLuGoodsDetailBanner.h
//  Face_App
//
//  Created by ma c on 16/4/7.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuGoodsDetailBanner : NSObject

//图片地址 
@property (nonatomic, strong) NSString *ImgView;
//图片类型 【1.轮播位图片；2.详情图片；3.实拍图片】
@property (nonatomic, strong) NSString *ImgType;
//图片高度
@property (nonatomic, strong) NSString *Resolution;

@end
