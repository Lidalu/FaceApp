//
//  LLuShopGoods.h
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuShopGoods : NSObject

/*
 Abbreviation = "Debon蝶妆海皙蓝晶透嫩白霜45g";
 Alert = 0;
 BuyCount = 200;
 CountryImg = "http://123.57.141.249:8080/beautalk/localfile/country/6c3374a4-0fe8-eebe-afcf-4a9a7c522cc3.jpeg";
 CountryName = "Korea 韩国原装";
 Discount = "";
 DomesticPrice = 300;
 ForeignPrice = "￥209";
 GoodsId = "c89b5563-78cb-4fef-aec5-e1266cfce6b1";
 GoodsIntro = "清爽的水分状，通气型水分保湿膜，保湿美白双管齐下";
 ImgView = "http://123.57.141.249:8080/beautalk/localfile/c89b5563-78cb-4fef-aec5-e1266cfce6b1/goods/52515dc2-e318-4efd-9ae8-6234e82de2ed.JPG";
 OtherPrice = "海外官网价：￥209 大陆官网价：￥300";
 Price = "￥100.0";
 Stock = 0;
 Title = "Debon蝶妆";
 */

@property (nonatomic, copy) NSString *Abbreviation;
@property (nonatomic, strong) NSNumber *Alert;
@property (nonatomic, strong) NSNumber *BuyCount;
@property (nonatomic, copy) NSString *CountryImg;
@property (nonatomic, copy) NSString *CountryName;
@property (nonatomic, copy) NSString *Discount;
@property (nonatomic, strong) NSNumber *DomesticPrice;
@property (nonatomic, copy) NSString *ForeignPrice;
@property (nonatomic, copy) NSString *GoodsId;
@property (nonatomic, copy) NSString *GoodsIntro;
@property (nonatomic, copy) NSString *ImgView;
@property (nonatomic, copy) NSString *OtherPrice;
@property (nonatomic, copy) NSString *Price;
@property (nonatomic, strong) NSNumber *Stock;
@property (nonatomic, copy) NSString *Title;

@end
