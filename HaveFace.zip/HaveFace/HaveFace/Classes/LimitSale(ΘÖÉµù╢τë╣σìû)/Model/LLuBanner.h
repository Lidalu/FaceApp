//
//  LLuBanner.h
//  有面儿App
//
//  Created by ma c on 16/4/5.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuBanner : NSObject

@property (nonatomic, copy) NSString *ImgView;
@property (nonatomic, copy) NSString *CommodityText;
@property (nonatomic, strong) NSNumber *IfMiddlePage;
@property (nonatomic, copy) NSString *RelatedId;

@end
