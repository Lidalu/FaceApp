//
//  LLuBrandGroup.h
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuBrandGroup : NSObject

//图片地址
@property (nonatomic, copy) NSString *ImgView;
//活动简介
@property (nonatomic, copy) NSString *CommodityText;
//是否有中间页
@property (nonatomic, assign) BOOL IfMiddlePage;
@property (nonatomic, copy) NSString *ActivityDate;
@property (nonatomic, copy) NSString *Content;
//活动ID
@property (nonatomic, copy) NSString *ActivityId;
//品牌LOGO图片地址
@property (nonatomic, copy) NSString *LogoImg;
//活动时间（距离结束时间）
@property (nonatomic, copy) NSString *FormetDate;
//品牌名称
@property (nonatomic, copy) NSString *ShopTitle;

@end
