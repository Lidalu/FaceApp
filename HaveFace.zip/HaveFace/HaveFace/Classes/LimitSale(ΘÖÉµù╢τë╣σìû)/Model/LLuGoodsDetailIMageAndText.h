//
//  LLuGoodsDetailIMageAndText.h
//  Face_App
//
//  Created by ma c on 16/4/8.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuGoodsDetailIMageAndText : NSObject

@property (nonatomic, copy) NSString *Title;

@property (nonatomic, copy) NSString *Value;

@end
