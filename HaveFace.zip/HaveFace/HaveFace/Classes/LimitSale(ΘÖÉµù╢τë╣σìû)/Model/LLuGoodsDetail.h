//
//  LLuGoodsDetail.h
//  Face_App
//
//  Created by ma c on 16/4/7.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuGoodsDetail : NSObject

//Abbreviation = "韩国 Beyond X 迪士尼爱丽丝梦游仙境 2016限量保湿气垫bb霜";
//ActivityName = "<null>";
//ActivityTime = "还剩361天6时50分";
//BrandCNName = "LG生活健康";
//BuyCount = "400人已购买";
//CountryName = "韩国";
//Discount = "0.2";
//DomesticPrice = 300;
//FavorableRate = "100%";
//GoodsId = "7eb01e23-993d-4f91-9677-b074121338bb";
//GoodsIntro = "Beyond 属 LG 旗下护肤品品牌，加上又是有机品牌，敏感型和孕妇都可以使用，是信心之选!~";
//GoodsTitle = Beyond;
//HtmUrl = "http://app.meihuishuo.com:8080/beautalk/goods/share.do?GoodsId=7eb01e23-993d-4f91-9677-b074121338bb";
//Notice = 0;
//OriginalPrice = "￥300";
//OverseasPrice = "￥200";
//Price = "￥7.0";
//Reputation = 0;
//Score = "5.0";
//ShareContent = "Beyond 属 LG 旗下护肤品品牌，加上又是有机品牌，敏感型和孕妇都可以使用，是信心之选!~";
//ShareImage = "http://123.57.141.249:8080/beautalk/localfile/7eb01e23-993d-4f91-9677-b074121338bb/goods/73640c92-3e5c-4aee-9756-e41036dedbac.JPG";
//ShareTitle = Beyond;
//ShopId = "147a95c0-b1db-426c-b3e4-715fe4da5631";
//ShopImage = "http://123.57.141.249:8080/beautalk/localfile/147a95c0-b1db-426c-b3e4-715fe4da5631/73d07721-7ed4-4b95-b05d-a69c6211da3e.JPG";
//Stock = 2000;
//isCollected = NO;


@property (nonatomic, copy, readonly) NSString *OriginalPrice;
@property (nonatomic, copy, readonly) NSString *OverseasPrice;
@property (nonatomic, copy, readonly) NSString *BuyCount;
@property (nonatomic, copy, readonly) NSString *Abbreviation;
@property (nonatomic, copy, readonly) NSString *Discount;
@property (nonatomic, copy, readonly) NSString *GoodsIntro;
@property (nonatomic, strong, readonly) NSNumber * DomesticPrice;
@property (nonatomic, assign, readonly) BOOL isCollected;
/**品牌图标*/
@property (copy, nonatomic) NSString *ShopImage;
/**品牌名称*/
@property (copy, nonatomic) NSString *BrandCNName;
/**品牌ID*/
@property (copy, nonatomic) NSString *ShopId;
/**品牌国家名称*/
@property (copy, nonatomic) NSString *CountryName;

@end
