//
//  LLuNewsGroup.h
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuNewsGroup : NSObject

/**商品名称*/
@property (copy, nonatomic) NSString *Title;

@property (nonatomic, copy) NSString *Abbreviation;
//国家图片
@property (nonatomic, copy) NSString *CountryImg;
//国家名字
@property (nonatomic, copy) NSString *CountryName;
//商品介绍
@property (nonatomic, copy) NSString *GoodsIntro;
//商品图片
@property (nonatomic, copy) NSString *ImgView;
//商品ID
@property (nonatomic, copy) NSString *GoodsId;
//剩余时间
@property (nonatomic, copy) NSString *RestTime;
//国内价格
@property (nonatomic, copy) NSString *DomesticPrice;
//国外价格
@property (nonatomic, copy) NSNumber *ForeignPrice;

/**原价格*/
@property (copy, nonatomic) NSString *Price;

@end
