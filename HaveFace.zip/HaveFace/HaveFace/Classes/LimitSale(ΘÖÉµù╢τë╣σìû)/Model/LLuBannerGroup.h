//
//  LLuBannerGroup.h
//  有面儿App
//
//  Created by ma c on 16/4/5.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuBannerGroup : NSObject

@property (nonatomic, strong) NSString *GrouponId;
@property (nonatomic, strong) NSString *ImgView;
@property (nonatomic, strong) NSNumber *Resolution;

@end
