//
//  LLuTableViewHeaderSectionView.h
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLuTableViewHeaderSectionView : UITableViewHeaderFooterView

- (instancetype)initWithFrame:(CGRect)frame;

//新品团购
@property (nonatomic, strong) UIButton *newsGroupBtn;
//品牌团购
@property (nonatomic, strong) UIButton *brandGroupBtn;

@end
