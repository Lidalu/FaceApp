//
//  LLuShopGoodsCollectionViewCell.h
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLuShopGoods.h"

@interface LLuShopGoodsCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) LLuShopGoods *shopGoods;

@end
