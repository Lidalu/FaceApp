//
//  LLuCollectionViewFlowLayout.m
//  高仿美团
//
//  Created by ma c on 3/7/16.
//  Copyright © 2016 lu. All rights reserved.
//

#import "LLuCollectionViewFlowLayout.h"

@implementation LLuCollectionViewFlowLayout

- (instancetype)init {
    
    self = [super init];
    if (self) {
        
        self.scrollDirection = UICollectionViewScrollDirectionVertical;
        self.itemSize = CGSizeMake((SCREEN_WIDTH-10)/2.0f, 320);
        self.minimumInteritemSpacing = 10;
        self.minimumLineSpacing = 10;
    }
    return self;
}

@end
