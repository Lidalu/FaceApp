//
//  LLuCollectionViewFlowLayout.h
//  高仿美团
//
//  Created by ma c on 3/7/16.
//  Copyright © 2016 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLuCollectionViewFlowLayout : UICollectionViewFlowLayout

@end
