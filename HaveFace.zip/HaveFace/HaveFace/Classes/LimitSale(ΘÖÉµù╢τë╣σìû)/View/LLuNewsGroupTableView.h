//
//  LLuNewsGroupTableView.h
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLuNewsGroupTableView : UITableView

+ (instancetype)newsGroupTableViewWithFrame:(CGRect)frame superView:(UIView *)superView;

@property (nonatomic, strong) NSMutableArray *newsGroupDataList;

@property (nonatomic, weak) id <LLuChildTableViewCellDelegate> childTableViewDelegate;

@end
