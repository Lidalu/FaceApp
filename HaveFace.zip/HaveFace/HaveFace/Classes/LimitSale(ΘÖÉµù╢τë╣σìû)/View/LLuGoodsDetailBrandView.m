//
//  LLuGoodsDetailBrandView.m
//  Face_App
//
//  Created by ma c on 16/4/8.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuGoodsDetailBrandView.h"

@interface LLuGoodsDetailBrandView ()

@property (strong, nonatomic)   UIImageView *brandImage;              /** 品牌图标 */
@property (strong, nonatomic)   UILabel *brandLabel;              /** 品牌名字 */
@property (strong, nonatomic)   UIImageView *countryImage;              /** 国旗 */
@property (strong, nonatomic)   UILabel *countryLabel;              /** 国家名字 */
@property (strong, nonatomic)   UILabel *backLabel1;              /** 浅灰色背景1 */
@property (strong, nonatomic)   UILabel *backLabel2;              /** 浅灰色背景2 */
@property (strong, nonatomic)   UILabel *tostLabel;              /** 图文详情label */
@property (strong, nonatomic)   UILabel *lineLabel2;              /** 底部分割线label */
@property (nonatomic, strong)   UILabel *sameLabel;                 /**查看同类商品 */
@property (nonatomic, strong)   UIImageView *indicatorImageView;    /**附属箭头 */

@end

@implementation LLuGoodsDetailBrandView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.backLabel1];
        [self addSubview:self.whiteButton];
        [self addSubview:self.brandImage];
        [self addSubview:self.brandLabel];
        [self addSubview:self.countryImage];
        [self addSubview:self.countryLabel];
        [self addSubview:self.backLabel2];
        [self addSubview:self.tostLabel];
        [self addSubview:self.lineLabel2];
        [self addSubview:self.sameLabel];
        [self addSubview:self.indicatorImageView];
    }
    return self;
}

- (void)layoutSubviews {
    
    [super layoutSubviews];
    WS(weakSelf);
    
    
    [_backLabel1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.top).offset(20);
        make.left.equalTo(weakSelf.mas_left);
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 10));
    }];
    
    [_whiteButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.backLabel1.mas_bottom);
        make.left.equalTo(weakSelf.mas_left);
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 80));
    }];

    [_brandImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.equalTo(CGSizeMake(50, 50));
        make.centerY.equalTo(weakSelf.whiteButton.mas_centerY);
        make.left.equalTo(16);
    }];

    [_brandLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.brandImage.mas_top).offset(5);
        make.left.equalTo(weakSelf.brandImage.mas_right).offset(16);
        make.height.equalTo(14);
        make.right.equalTo(weakSelf.mas_right).offset(-30);
    }];

    [_countryImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(weakSelf.brandImage.mas_bottom).offset(-5);
        make.left.equalTo(weakSelf.brandImage.mas_right).offset(16);
        make.size.equalTo(CGSizeMake(18, 13));
    }];

    [_countryLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.countryImage.mas_right).offset(10);
        make.centerY.equalTo(weakSelf.countryImage.mas_centerY);
        make.height.offset(13);
        make.right.equalTo(weakSelf.mas_right).offset(-30);
    }];
    
    [_backLabel2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 10));
        make.top.equalTo(weakSelf.whiteButton.mas_bottom);
        make.left.equalTo(weakSelf.mas_left);
    }];

    [_tostLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.mas_left).offset(16);
        make.top.equalTo(weakSelf.backLabel2.mas_bottom).offset(15);
        make.size.equalTo(CGSizeMake(70, 15));
    }];
    
    [_lineLabel2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.tostLabel.mas_bottom).offset(18);
        make.right.equalTo(weakSelf.mas_right).offset(-15);
        make.left.equalTo(weakSelf.mas_left).offset(15);
        make.height.equalTo(1);
    }];
    
    [_indicatorImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.centerY.equalTo(weakSelf.whiteButton.mas_centerY);
        make.right.equalTo(weakSelf.mas_right).offset(-16);
        make.size.equalTo(CGSizeMake(14, 14));
    }];
    
    [_sameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.centerY.equalTo(weakSelf.whiteButton.mas_centerY);
        make.right.equalTo(weakSelf.indicatorImageView.mas_left).offset(-5);
        make.height.equalTo(@14);
    }];
}

- (void)setGoodsDetail:(LLuGoodsDetail *)goodsDetail {
    
    _goodsDetail = goodsDetail;
    
    NSURL *url = [NSURL URLWithString:goodsDetail.ShopImage];
    
    [_brandImage sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"分类界面t区黑头图标"] options:SDWebImageRetryFailed | SDWebImageLowPriority | SDWebImageProgressiveDownload | SDWebImageContinueInBackground];
    
    _brandLabel.text = goodsDetail.BrandCNName;
    _countryLabel.text = goodsDetail.CountryName;
    
}

- (UILabel *)backLabel1{
    if (!_backLabel1) {
        _backLabel1 = [[UILabel alloc]init];
        _backLabel1.backgroundColor = RGB(245, 245, 245);
    }
    return _backLabel1;
}

- (UIButton *)whiteButton{
    if (!_whiteButton) {
        _whiteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _whiteButton.backgroundColor = [UIColor whiteColor];
        
    }
    return _whiteButton;
}

- (UIImageView *)brandImage{
    if (!_brandImage) {
        _brandImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"分类界面唇膏图标"]];
    }
    return _brandImage;
}

- (UILabel *)brandLabel{
    if (!_brandLabel) {
        _brandLabel = [[UILabel alloc]init];
        _brandLabel.textAlignment = NSTextAlignmentLeft;
        _brandLabel.font = [UIFont systemFontOfSize:13.0];
        _brandLabel.textColor = RGB(23, 23, 23);
    }
    return _brandLabel;
}

- (UIImageView *)countryImage{
    if (!_countryImage) {
        _countryImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"分类界面口腔洁牙图标"]];
    }
    return _countryImage;
}

- (UILabel *)countryLabel{
    if (!_countryLabel) {
        _countryLabel = [[UILabel alloc]init];
        _countryLabel.textAlignment = NSTextAlignmentLeft;
        _countryLabel.font = [UIFont systemFontOfSize:13.0];
        _countryLabel.textColor = RGB(23, 23, 23);

    }
    return _countryLabel;
}

- (UILabel *)backLabel2{
    if (!_backLabel2) {
        _backLabel2 = [[UILabel alloc]init];
        _backLabel2.backgroundColor = RGB(245, 245, 245);
    }
    return _backLabel2;
}

- (UILabel *)tostLabel{
    if (!_tostLabel) {
        _tostLabel = [[UILabel alloc]init];
        _tostLabel.text = @"图文详情";
        _tostLabel.font = [UIFont systemFontOfSize:15.0];
        _tostLabel.textAlignment = NSTextAlignmentLeft;
    }
    return _tostLabel;
}

- (UILabel *)lineLabel2{
    if (!_lineLabel2) {
        _lineLabel2 = [[UILabel alloc]init];
        _lineLabel2.backgroundColor = RGB(245, 245, 245);
    }
    return _lineLabel2;
}

- (UILabel *)sameLabel {
    
    if (!_sameLabel) {
        
        _sameLabel = [[UILabel alloc] init];
        _sameLabel.text = @"(查看同品牌商品)";
        _sameLabel.font = [UIFont systemFontOfSize:14];
        _sameLabel.textColor = [UIColor darkTextColor];
        _sameLabel.adjustsFontSizeToFitWidth = YES;
    }
    return _sameLabel;
}

- (UIImageView *)indicatorImageView {
    
    if (!_indicatorImageView) {
        
        _indicatorImageView = [[UIImageView alloc] init];
        _indicatorImageView.image = [UIImage imageNamed:@"right_normal"];
    }
    return _indicatorImageView;
}

@end
