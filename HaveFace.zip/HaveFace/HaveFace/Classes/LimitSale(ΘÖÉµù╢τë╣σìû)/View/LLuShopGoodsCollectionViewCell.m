//
//  LLuShopGoodsCollectionViewCell.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuShopGoodsCollectionViewCell.h"

@interface LLuShopGoodsCollectionViewCell ()

@property (nonatomic, strong) UIImageView *countryImgView;

@property (nonatomic, strong) UIImageView *goodsImgView;

@property (nonatomic, strong) UILabel *goodsTitleLabel;

@property (nonatomic, strong) UILabel *priceLabel;

@end

@implementation LLuShopGoodsCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)setShopGoods:(LLuShopGoods *)shopGoods {
    
    _shopGoods = shopGoods;
    
    NSURL *countryImgUrl = [NSURL URLWithString:shopGoods.CountryImg];
    NSURL *goodImgUrl = [NSURL URLWithString:shopGoods.ImgView];
    [self.countryImgView sd_setImageWithURL:countryImgUrl placeholderImage:[UIImage imageNamed:@"nav_backImage"] options:SDWebImageRetryFailed | SDWebImageLowPriority | SDWebImageProgressiveDownload | SDWebImageContinueInBackground];
    
    [self.goodsImgView sd_setImageWithURL:goodImgUrl placeholderImage:[UIImage imageNamed:@"nav_backImage"] options:SDWebImageRetryFailed | SDWebImageLowPriority | SDWebImageProgressiveDownload | SDWebImageContinueInBackground];

    self.priceLabel.attributedText = [NSMutableAttributedString makeStrikethroughAttributedString2:shopGoods.Price :[shopGoods.DomesticPrice stringValue]];
    
//    NSString *titleString = [NSString stringWithFormat:@"【%@】%@", shopGoods.CountryName, shopGoods.Abbreviation];
    NSString *titleString = [NSString stringWithFormat:@"  %@", shopGoods.Abbreviation];
    self.goodsTitleLabel.text = titleString;
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
//        self.backgroundColor = [UIColor blueColor];
        self.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:self.goodsImgView];
        [self.contentView addSubview:self.countryImgView];
        [self.contentView addSubview:self.goodsTitleLabel];
        [self.contentView addSubview:self.priceLabel];
    }
    return self;
}

- (void)layoutSubviews {
    
    [super layoutSubviews];
    WS(weakSelf);
    
    
    [_goodsImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.top.right.equalTo(weakSelf);
        make.height.equalTo(weakSelf.mas_width).multipliedBy(1.0f);
    }];
    
    [_countryImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.mas_top).offset(11);
        make.left.equalTo(weakSelf.mas_left).offset(10);
        make.size.equalTo(CGSizeMake(22, 16));
    }];

    [_goodsTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.goodsImgView.mas_bottom).offset(10);
        make.left.equalTo(weakSelf.mas_left).offset(11);
        make.right.equalTo(weakSelf.mas_right).offset(-11);
//        make.height.equalTo(@50);
    }];
    
    [_priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
       
        make.top.equalTo(weakSelf.goodsTitleLabel.mas_bottom).offset(12);
        make.left.right.equalTo(weakSelf);
        make.bottom.equalTo(weakSelf.mas_bottom).offset(-13);
        
        
    }];
    
}


- (UIImageView *)goodsImgView {
    
    if (!_goodsImgView) {
        
        _goodsImgView = [[UIImageView alloc] init];
        _goodsImgView.backgroundColor = [UIColor grayColor];
    }
    return _goodsImgView;
}

- (UIImageView *)countryImgView {
    
    if (!_countryImgView) {
        
        _countryImgView = [[UIImageView alloc] init];
        _countryImgView.backgroundColor = [UIColor grayColor];
    }
    return _countryImgView;
}

- (UILabel *)goodsTitleLabel {
    
    if (!_goodsTitleLabel) {
        
        _goodsTitleLabel = [[UILabel alloc] init];
//        _goodsTitleLabel.backgroundColor = [UIColor orangeColor];
        _goodsTitleLabel.backgroundColor = [UIColor whiteColor];
        _goodsTitleLabel.numberOfLines = 0;
        [_goodsTitleLabel sizeToFit];
    }
    return _goodsTitleLabel;
}

- (UILabel *)priceLabel {
    
    if (!_priceLabel) {
        
        _priceLabel = [[UILabel alloc] init];
//        _priceLabel.backgroundColor = [UIColor purpleColor];
        _priceLabel.backgroundColor = [UIColor whiteColor];
        _priceLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _priceLabel;
}


@end
