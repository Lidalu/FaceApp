//
//  LLuGoodsDetailBrandView.h
//  Face_App
//
//  Created by ma c on 16/4/8.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLuGoodsDetail.h"

@interface LLuGoodsDetailBrandView : UIView

@property (strong, nonatomic)   UIButton *whiteButton;              /** 白色背景 */

@property (nonatomic, strong) LLuGoodsDetail *goodsDetail;

@end
