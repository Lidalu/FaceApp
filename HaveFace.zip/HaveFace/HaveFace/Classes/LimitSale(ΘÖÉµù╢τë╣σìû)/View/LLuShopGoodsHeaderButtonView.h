//
//  LLuShopGoodsHeaderButtonView.h
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLuShopGoodsHeaderButtonView : UIView

///热门
@property (nonatomic, strong) UIButton *hotButton;
///价格
@property (nonatomic, strong) UIButton *priceButton;
///好评
@property (nonatomic, strong) UIButton *scoreButton;
///新品
@property (nonatomic, strong) UIButton *timeButton;

@property (nonatomic, strong) UIView *lineView;

@end
