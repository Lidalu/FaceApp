//
//  LLuTableViewHeaderSectionView.m
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuTableViewHeaderSectionView.h"

@interface LLuTableViewHeaderSectionView ()

@end

@implementation LLuTableViewHeaderSectionView

- (UIButton *)newsGroupBtn {
    
    if (!_newsGroupBtn) {
        
        _newsGroupBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _newsGroupBtn.frame = CGRectMake(0, 0, SCREEN_WIDTH/2.0f, CGRectGetHeight(self.frame));
        _newsGroupBtn.tag = 0;
        [_newsGroupBtn setImage:[UIImage imageNamed:@"新品团未选中"] forState:UIControlStateNormal];
        [_newsGroupBtn setImage:[UIImage imageNamed:@"新品团选中"] forState:UIControlStateSelected];
        _newsGroupBtn.adjustsImageWhenHighlighted = NO;
        //对button的显示的图片添加便宜量
        [_newsGroupBtn setImageEdgeInsets:UIEdgeInsetsMake(0, -40, 0, 0)];
        [_newsGroupBtn setTitle:@"新品团购" forState:(UIControlStateNormal)];
        [_newsGroupBtn setTitleColor:RGB(67, 182, 241) forState:(UIControlStateNormal)];
        [_newsGroupBtn setTitleColor:RGB(239, 101, 48) forState:(UIControlStateSelected)];
        _newsGroupBtn.selected = YES;
    }
    return _newsGroupBtn;
}

- (UIButton *)brandGroupBtn {
    
    if (!_brandGroupBtn) {
        
        _brandGroupBtn =[UIButton buttonWithType:UIButtonTypeCustom];
        _brandGroupBtn.frame = CGRectMake(SCREEN_WIDTH/2.0f, 0, SCREEN_WIDTH/2.0f, CGRectGetHeight(self.frame));
        _brandGroupBtn.tag = 1;
        [_brandGroupBtn setImage:[UIImage imageNamed:@"品牌团未选中"] forState:UIControlStateNormal];
        [_brandGroupBtn setImage:[UIImage imageNamed:@"品牌团选中"] forState:UIControlStateSelected];
        _brandGroupBtn.adjustsImageWhenHighlighted = NO;
        [_brandGroupBtn setImageEdgeInsets:UIEdgeInsetsMake(0, -40, 0, 0)];
        [_brandGroupBtn setTitle:@"品牌团购" forState:(UIControlStateNormal)];
        [_brandGroupBtn setTitleColor:RGB(67, 182, 241) forState:(UIControlStateNormal)];
        [_brandGroupBtn setTitleColor:RGB(239, 101, 48) forState:(UIControlStateSelected)];
    }
    return _brandGroupBtn;
}

+ (instancetype)headerSectionView {
    
    
    return [[self alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 75)];
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.newsGroupBtn];
        [self addSubview:self.brandGroupBtn];
    }
    return self;
}

- (void)layoutSubviews {
    

}


@end
