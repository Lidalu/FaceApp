//
//  LLuGoodsDetailIMageAndTextView.m
//  Face_App
//
//  Created by ma c on 16/4/8.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuGoodsDetailIMageAndTextView.h"

@interface LLuGoodsDetailIMageAndTextView ()

@end

@implementation LLuGoodsDetailIMageAndTextView

- (void)setGoodsDetailItems:(NSArray *)goodsDetailItems {
    
    _goodsDetailItems = goodsDetailItems;

    self.labelH = 30;
    for (NSInteger i = 0; i < _goodsDetailItems.count; i++) {
        
        LLuGoodsDetailIMageAndText *goodsDetailItem = _goodsDetailItems[i];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(25, _labelH * i, SCREEN_WIDTH - 50, _labelH)];
        label.backgroundColor = [UIColor whiteColor];
        label.font = [UIFont systemFontOfSize:15];
        NSString *labelText = [NSString stringWithFormat:@"%@：%@", goodsDetailItem.Title, goodsDetailItem.Value];
        label.text = labelText;
        
        [self addSubview:label];
    }
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

@end
