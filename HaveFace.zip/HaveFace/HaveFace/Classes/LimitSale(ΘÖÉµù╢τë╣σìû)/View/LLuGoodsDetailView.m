//
//  LLuGoodsDetailView.m
//  Face_App
//
//  Created by ma c on 16/4/7.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuGoodsDetailView.h"

@interface LLuGoodsDetailView ()

@property (nonatomic, strong) UILabel *goodsNameLabel;
@property (nonatomic, strong) UILabel *priceLabel;
@property (nonatomic, strong) UILabel *discountLabel;

@property (nonatomic, strong) UILabel *buyCountLabel;

@property (nonatomic, strong) UIView *GoodsIntroView;

@property (nonatomic, strong) UILabel *GoodsIntroLabel;

@end

@implementation LLuGoodsDetailView

#pragma mark - setter and getter

- (void)setGoodsDetail:(LLuGoodsDetail *)goodsDetail {
    
    _goodsDetail = goodsDetail;
    self.goodsNameLabel.text = goodsDetail.Abbreviation;
    
    NSString *buyCount = [NSString stringWithFormat:@"  %@", goodsDetail.BuyCount];
    self.buyCountLabel.text = buyCount;
    
    _priceLabel.attributedText = [NSMutableAttributedString makeStrikethroughAttributedString:[goodsDetail.DomesticPrice stringValue] :goodsDetail.OverseasPrice];

    self.GoodsIntroLabel.text = goodsDetail.GoodsIntro;

    NSString *discountString = [NSString stringWithFormat:@"(%@折)", goodsDetail.Discount];
    self.discountLabel.text = discountString;
}

- (UILabel *)goodsNameLabel {
    
    if (!_goodsNameLabel) {
        
        _goodsNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
//        _goodsNameLabel.text = @"都不卡恩的爱副卡不擦金额不放弃我哭泣的";
//        _goodsNameLabel.backgroundColor = [UIColor orangeColor];
        _goodsNameLabel.numberOfLines = 0;

    }
    return _goodsNameLabel;
}

- (UILabel *)priceLabel {
    
    if (!_priceLabel) {
        
        _priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 150, 100, 100)];
//        _priceLabel.backgroundColor = [UIColor purpleColor];
    }
    return _priceLabel;
}

- (UILabel *)GoodsIntroLabel {
    
    if (!_GoodsIntroLabel) {
        
        _GoodsIntroLabel = [[UILabel alloc] init];
        _GoodsIntroLabel.textColor = [UIColor lightGrayColor];
//        _GoodsIntroLabel.backgroundColor = [UIColor redColor];
        _GoodsIntroLabel.font = [UIFont systemFontOfSize:14];
        _GoodsIntroLabel.numberOfLines = 0;
//        _GoodsIntroLabel.text = @"不包括就粉色不服而是被疯狂宝贝都无爱贷款";
    }
    return _GoodsIntroLabel;
}

- (UIView *)GoodsIntroView {
    
    if (!_GoodsIntroView) {
        
        _GoodsIntroView = [[UIView alloc] initWithFrame:CGRectMake(0, 100, 200, 200)];
        
        UILabel *lineLabel = [[UILabel alloc] initWithFrame:CGRectMake(25, 0, SCREEN_WIDTH - 50, 0.5)];
        lineLabel.backgroundColor = [UIColor lightGrayColor];
        
        [_GoodsIntroView addSubview:lineLabel];
        [_GoodsIntroView addSubview:self.GoodsIntroLabel];
    }
    return _GoodsIntroView;
}

- (UILabel *)buyCountLabel {
    
    if (!_buyCountLabel) {
        
        _buyCountLabel = [[UILabel alloc] init];
        _buyCountLabel.backgroundColor = [UIColor colorWithRed:0.9882 green:0.2078 blue:0.0314 alpha:1.0];
        _buyCountLabel.textColor = [UIColor whiteColor];
        _buyCountLabel.font = [UIFont systemFontOfSize:16];
        _buyCountLabel.layer.cornerRadius = 13;
        _buyCountLabel.layer.masksToBounds = YES;
    }
    return _buyCountLabel;
}

- (UILabel *)discountLabel {
    
    if (!_discountLabel) {
        
        _discountLabel = [[UILabel alloc] init];
        _discountLabel.font = [UIFont systemFontOfSize:14];
    }
    return _discountLabel;
}

- (instancetype)initWithFrame:(CGRect)frame {

    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        [self addSubview:self.goodsNameLabel];
        [self addSubview:self.priceLabel];
        [self addSubview:self.GoodsIntroView];
        [self addSubview:self.discountLabel];
        [self addSubview:self.buyCountLabel];
        
    }
    return self;
}

- (void)layoutSubviews {
    
    [super layoutSubviews];
    WS(weakSelf);
    [_buyCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.mas_top).offset(10);
        make.width.equalTo(@144);
        make.left.equalTo(weakSelf.mas_right).offset(-110);
        make.height.equalTo(@30);
    }];
    
    [_goodsNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.width.equalTo(weakSelf.mas_width).multipliedBy(0.8);
        make.center.equalTo(weakSelf);
    }];
    
    [_priceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.centerX.equalTo(weakSelf).offset(-10);
        make.top.equalTo(weakSelf.goodsNameLabel.mas_bottom).offset(20);
    }];
    
    _priceLabel.adjustsFontSizeToFitWidth = YES;
    
    [_discountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.priceLabel.mas_right).offset(10);
        make.centerY.equalTo(weakSelf.priceLabel.mas_centerY);
    }];
    _discountLabel.adjustsFontSizeToFitWidth = YES;
    
    [_GoodsIntroView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.priceLabel.mas_bottom).offset(10);
        make.bottom.equalTo(weakSelf);
        make.left.right.equalTo(weakSelf);
//        make.height.equalTo(@50);
    }];
    
    [_GoodsIntroLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.GoodsIntroView.mas_top).offset(1);
        make.left.equalTo(weakSelf.GoodsIntroView.mas_left).offset(25);
        make.right.equalTo(weakSelf.GoodsIntroView.mas_right).offset(-15);
//        make.bottom.equalTo(weakSelf.GoodsIntroView);
        make.height.equalTo(@50);
    }];
    [_GoodsIntroLabel setAdjustsFontSizeToFitWidth:YES];
}

@end
