//
//  LLuNewsGroupTableView.m
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuNewsGroupTableView.h"
#import "LLuNewsGroupTableViewCell.h"
#import "LLuNewsGroup.h"

static NSString *newsGroupTableViewCellID = @"newsGroupTableViewCellID";

@interface LLuNewsGroupTableView () <UITableViewDelegate, UITableViewDataSource>

@end

@implementation LLuNewsGroupTableView

+ (instancetype)newsGroupTableViewWithFrame:(CGRect)frame superView:(UIView *)superView {
    
    LLuNewsGroupTableView *newsGroupTableView = [[LLuNewsGroupTableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    [superView addSubview:newsGroupTableView];
    return newsGroupTableView;
}

#pragma mark - setter and getter

- (NSMutableArray *)newsGroupDataList {
    
    if (!_newsGroupDataList) {
        
        _newsGroupDataList = [NSMutableArray array];
    }
    return _newsGroupDataList;
}

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    
    self = [super initWithFrame:frame style:style];
    if (self) {
        
        self.delegate = self;
        self.bounces = NO;
        self.dataSource = self;
        self.sectionHeaderHeight = 0;
        self.sectionFooterHeight = 0;
        self.rowHeight = 173;
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self registerClass:[LLuNewsGroupTableViewCell class] forCellReuseIdentifier:newsGroupTableViewCellID];
    }
    return self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.newsGroupDataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    LLuNewsGroupTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:newsGroupTableViewCellID];
    cell.newsGroup = self.newsGroupDataList[indexPath.row];
    UIView *view_bg = [[UIView alloc]initWithFrame:cell.frame];
    
    view_bg.backgroundColor = [UIColor clearColor];
    
    cell.selectedBackgroundView = view_bg;
    return cell;
}

#pragma mark - 设置cell分割线
- (void)viewDidLayoutSubviews {
    
    if ([self respondsToSelector:@selector(setSeparatorInset:)]) {
        [self setSeparatorInset:UIEdgeInsetsMake(0,0,0,0)];
    }
    
    if ([self respondsToSelector:@selector(setLayoutMargins:)]) {
        [self setLayoutMargins:UIEdgeInsetsMake(0,0,0,0)];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
//    NSLog(@"newsGroupTableView点击了");
    
//    LLuNewsGroup *newsGroup = self.newsGroupDataList[indexPath.row];
//    LLULog(@"row ====%lu", indexPath.row);
//    LLULog(@"newsGroup===%@", newsGroup.Title);
//    LLULog(@"newsGroup===%@", newsGroup.CountryName);
    if ([self.childTableViewDelegate respondsToSelector:@selector(childTableView:CellDidClickWithIndexPath:)]) {
        
        [self.childTableViewDelegate childTableView:self CellDidClickWithIndexPath:indexPath.row];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

@end
