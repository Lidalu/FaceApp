//
//  LLuGoodsDetailImageView.h
//  Face_App
//
//  Created by ma c on 16/4/8.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLuGoodsDetailBanner.h"

@interface LLuGoodsDetailImageView : UIView

@property (nonatomic, strong) NSArray *goodsDetailImageDataList;

@end
