//
//  LLuShopGoodsHeaderButtonView.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuShopGoodsHeaderButtonView.h"

@interface LLuShopGoodsHeaderButtonView ()


@end

@implementation LLuShopGoodsHeaderButtonView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];

        [self addSubview:self.hotButton];
        [self addSubview:self.priceButton];
        [self addSubview:self.scoreButton];
        [self addSubview:self.timeButton];
        [self addSubview:self.lineView];

    }
    return self;
}

- (void)layoutSubviews {
    
    [super layoutSubviews];
    
    WS(weakSelf);
    
    [_hotButton mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.top.equalTo(weakSelf);
        make.width.equalTo(weakSelf.mas_width).multipliedBy(1/4.0f);
        make.bottom.equalTo(weakSelf.mas_bottom).offset(-8);
    }];
    
    [_priceButton mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.hotButton.mas_right);
        make.top.equalTo(weakSelf);
        make.width.equalTo(weakSelf.mas_width).multipliedBy(1/4.0f);
        make.bottom.equalTo(weakSelf.mas_bottom).offset(-8);
    }];
    
    [_scoreButton mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.priceButton.mas_right);
        make.top.equalTo(weakSelf);
        make.width.equalTo(weakSelf.mas_width).multipliedBy(1/4.0f);
        make.bottom.equalTo(weakSelf.mas_bottom).offset(-8);
    }];
    
    [_timeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.scoreButton.mas_right);
        make.top.equalTo(weakSelf);
        make.width.equalTo(weakSelf.mas_width).multipliedBy(1/4.0f);
        make.bottom.equalTo(weakSelf.mas_bottom).offset(-8);
    }];
    
    [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.height.equalTo(@5);
        make.bottom.equalTo(weakSelf.mas_bottom);
        make.centerX.equalTo(weakSelf.hotButton.mas_centerX);
        make.width.equalTo(@70);
    }];
}

- (UIButton *)hotButton {
    
    if (!_hotButton) {
        
        _hotButton = [UIButton buttonWithType:UIButtonTypeCustom];
        
        _hotButton.backgroundColor = [UIColor whiteColor];
        [_hotButton setTitle:@"热门" forState:UIControlStateNormal];
        [_hotButton setTitle:@"热门" forState:UIControlStateSelected];
        [_hotButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [_hotButton setTitleColor:[UIColor colorWithRed:0.0824 green:0.651 blue:0.949 alpha:1.0] forState:UIControlStateSelected];
        _hotButton.tag = 1000;
        _hotButton.selected = YES;
    }
    return _hotButton;
}

-(UIButton *)priceButton {
    
    if (!_priceButton) {
        
        _priceButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _priceButton.backgroundColor = [UIColor whiteColor];
        [_priceButton setTitle:@"价格" forState:UIControlStateNormal];
        [_priceButton setTitle:@"价格" forState:UIControlStateSelected];
        [_priceButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [_priceButton setTitleColor:[UIColor colorWithRed:0.0824 green:0.651 blue:0.949 alpha:1.0] forState:UIControlStateSelected];
        _priceButton.tag = 1001;
    }
    return _priceButton;
}

- (UIButton *)scoreButton {
    
    if (!_scoreButton) {
        
        _scoreButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _scoreButton.backgroundColor = [UIColor whiteColor];
        [_scoreButton setTitle:@"好评" forState:UIControlStateNormal];
        [_scoreButton setTitle:@"好评" forState:UIControlStateSelected];
        [_scoreButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [_scoreButton setTitleColor:[UIColor colorWithRed:0.0824 green:0.651 blue:0.949 alpha:1.0] forState:UIControlStateSelected];
        _scoreButton.tag = 1002;
    }
    return _scoreButton;
}

- (UIButton *)timeButton {
    
    if (!_timeButton) {
        
        _timeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _timeButton.backgroundColor = [UIColor whiteColor];
        [_timeButton setTitle:@"新品" forState:UIControlStateNormal];
        [_timeButton setTitle:@"新品" forState:UIControlStateSelected];
        [_timeButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [_timeButton setTitleColor:[UIColor colorWithRed:0.0824 green:0.651 blue:0.949 alpha:1.0] forState:UIControlStateSelected];
        _timeButton.tag = 1003;
    }
    return _timeButton;
}

- (UIView *)lineView {
    
    if (!_lineView) {
        
        _lineView = [[UIView alloc] init];
//        _lineView.backgroundColor = [UIColor redColor];
        _lineView.backgroundColor = [UIColor colorWithRed:0.0824 green:0.651 blue:0.949 alpha:1.0];
    }
    return _lineView;
}

@end
