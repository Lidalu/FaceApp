//
//  LLuGoodsDetailIMageAndTextView.h
//  Face_App
//
//  Created by ma c on 16/4/8.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLuGoodsDetailIMageAndText.h"

@interface LLuGoodsDetailIMageAndTextView : UIView

@property (nonatomic, strong) NSArray *goodsDetailItems;

@property (nonatomic, assign) CGFloat labelH;

@end
