//
//  LLuBrandGroupTableViewCell.m
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuBrandGroupTableViewCell.h"

@interface LLuBrandGroupTableViewCell ()

@property (weak, nonatomic) IBOutlet UIImageView *brandImageView;

@end

@implementation LLuBrandGroupTableViewCell

- (void)setBrandGroup:(LLuBrandGroup *)brandGroup {
    
    _brandGroup = brandGroup;
    NSURL *brandUrl = [NSURL URLWithString:brandGroup.ImgView];
    [self.brandImageView sd_setImageWithURL:brandUrl placeholderImage:[UIImage imageNamed:@"tabbar_back"] options:SDWebImageRetryFailed | SDWebImageLowPriority | SDWebImageProgressiveDownload | SDWebImageContinueInBackground];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
