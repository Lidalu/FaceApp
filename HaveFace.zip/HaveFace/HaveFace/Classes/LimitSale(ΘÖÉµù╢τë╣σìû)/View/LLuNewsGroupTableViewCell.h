//
//  LLuNewsGroupTableViewCell.h
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLuNewsGroup.h"

@interface LLuNewsGroupTableViewCell : UITableViewCell

@property (nonatomic, strong) LLuNewsGroup *newsGroup;

@end
