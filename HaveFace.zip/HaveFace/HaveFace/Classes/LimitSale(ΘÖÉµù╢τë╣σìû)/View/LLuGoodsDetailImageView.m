//
//  LLuGoodsDetailImageView.m
//  Face_App
//
//  Created by ma c on 16/4/8.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuGoodsDetailImageView.h"

@implementation LLuGoodsDetailImageView

- (void)setGoodsDetailImageDataList:(NSArray *)goodsDetailImageDataList {
    
    _goodsDetailImageDataList = goodsDetailImageDataList;

    CGFloat imageViewY = 0.f;
    for (NSInteger i = 0; i < goodsDetailImageDataList.count; i++) {
        
        LLuGoodsDetailBanner *goodsDetailImage = goodsDetailImageDataList[i];

        CGFloat imageHeight = [goodsDetailImage.Resolution floatValue]*(SCREEN_WIDTH/[goodsDetailImage.Resolution floatValue]);
        
//        NSLog(@"%lf", imageHeight);
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, imageViewY, SCREEN_WIDTH, imageHeight)];
        
        imageViewY += imageHeight;
        
        NSURL *url = [NSURL URLWithString:goodsDetailImage.ImgView];
        [imageView sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"分类界面t区黑头图标"] options:SDWebImageRetryFailed | SDWebImageLowPriority | SDWebImageProgressiveDownload | SDWebImageContinueInBackground];
        
        [self addSubview:imageView];
    }
    
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

@end
