//
//  LLuBrandGroupTableView.m
//  有面儿App
//
//  Created by ma c on 16/4/6.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuBrandGroupTableView.h"
#import "LLuBrandGroupTableViewCell.h"
#import "LLuBrandGroup.h"

static NSString *brandGroupTableViewCellID = @"brandGroupTableViewCellID";

@interface LLuBrandGroupTableView ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong, readonly) NSIndexPath *brandIndexPath;

@end

@implementation LLuBrandGroupTableView


+ (instancetype)newsGroupTableViewWithFrame:(CGRect)frame superView:(UIView *)superView {
    
    LLuBrandGroupTableView *brandGroupTableView = [[LLuBrandGroupTableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    [superView addSubview:brandGroupTableView];
    return brandGroupTableView;
}

#pragma mark - setter and getter

- (NSMutableArray *)brandGroupDataList {
    
    if (!_brandGroupDataList) {
        
        _brandGroupDataList = [NSMutableArray array];
    }
    return _brandGroupDataList;
}

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    
    self = [super initWithFrame:frame style:style];
    if (self) {
        self.delegate = self;
        self.bounces = NO;
        self.dataSource = self;
        self.sectionHeaderHeight = 0;
        self.sectionFooterHeight = 0;
        self.rowHeight = 185;
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self registerNib:[UINib nibWithNibName:@"LLuBrandGroupTableViewCell" bundle:nil] forCellReuseIdentifier:brandGroupTableViewCellID];
        
    }
    return self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.brandGroupDataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    LLuBrandGroupTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:brandGroupTableViewCellID];
    cell.brandGroup = self.brandGroupDataList[indexPath.row];
    UIView *view_bg = [[UIView alloc]initWithFrame:cell.frame];
    
    view_bg.backgroundColor = [UIColor clearColor];
    
    cell.selectedBackgroundView = view_bg;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if ([self.childTableViewDelegate respondsToSelector:@selector(childTableView:CellDidClickWithIndexPath:)]) {
        
        [self.childTableViewDelegate childTableView:self CellDidClickWithIndexPath:indexPath.row];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

//- (void)cellDidClick {
//    
//    if ([self.childTableViewDelegate respondsToSelector:@selector(childTableView:CellDidClickWithIndexPath:)]) {
//        
//        [self.childTableViewDelegate childTableView:self CellDidClickWithIndexPath:self.brandIndexPath];
//    }
//}

@end
