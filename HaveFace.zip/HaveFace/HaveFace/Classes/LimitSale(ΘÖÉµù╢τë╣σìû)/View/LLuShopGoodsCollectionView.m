//
//  LLuShopGoodsCollectionView.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuShopGoodsCollectionView.h"
#import "LLuShopGoodsCollectionViewCell.h"
#import "LLuCollectionViewFlowLayout.h"

static NSString *shopGoodsCollectionViewCell = @"shopGoodsCollectionViewCell";
@interface LLuShopGoodsCollectionView () <UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>



@end

@implementation LLuShopGoodsCollectionView

+ (instancetype)shopGoodsCollectionViewWithFrame:(CGRect)frame {
    
    LLuCollectionViewFlowLayout *flowLayout = [[LLuCollectionViewFlowLayout alloc] init];
    
    LLuShopGoodsCollectionView *collectionView = [[LLuShopGoodsCollectionView alloc] initWithFrame:frame collectionViewLayout:flowLayout];
    
    
    return collectionView;
}

- (instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout {
    
    self = [super initWithFrame:frame collectionViewLayout:layout];
    if (self) {
        
        self.delegate = self;
        self.dataSource = self;
        self.contentInset = UIEdgeInsetsMake(0, 0, +60, 0);
//        self.backgroundColor = [UIColor greenColor];
        self.backgroundColor = [UIColor grayColor];
        self.showsHorizontalScrollIndicator = NO;
        
        [self registerClass:[LLuShopGoodsCollectionViewCell class] forCellWithReuseIdentifier:shopGoodsCollectionViewCell];
    }
    return self;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.shopGoodsDataList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    LLuShopGoodsCollectionViewCell *shopGoodsItem = [collectionView dequeueReusableCellWithReuseIdentifier:shopGoodsCollectionViewCell forIndexPath:indexPath];
    shopGoodsItem.shopGoods = self.shopGoodsDataList[indexPath.row];
    return shopGoodsItem;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    [collectionView deselectItemAtIndexPath:indexPath animated:NO];
}

@end
