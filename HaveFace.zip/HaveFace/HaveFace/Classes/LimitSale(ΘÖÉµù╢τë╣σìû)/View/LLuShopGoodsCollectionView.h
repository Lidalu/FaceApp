//
//  LLuShopGoodsCollectionView.h
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLuShopGoodsCollectionView : UICollectionView

@property (nonatomic, strong) NSArray *shopGoodsDataList;

+ (instancetype)shopGoodsCollectionViewWithFrame:(CGRect)frame;
@end
