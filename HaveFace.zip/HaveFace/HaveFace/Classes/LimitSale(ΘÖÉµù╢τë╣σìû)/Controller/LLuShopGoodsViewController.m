//
//  LLuShopGoodsViewController.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuShopGoodsViewController.h"
#import "LLuShopGoodsHeaderButtonView.h"
#import "LLuShopGoods.h"
#import "LLuShopGoodsCollectionView.h"

@interface LLuShopGoodsViewController ()

@property (nonatomic, strong) UIBarButtonItem *backItem;

@property (nonatomic, strong) LLuShopGoodsHeaderButtonView *headerBtnView;

@property (nonatomic, strong) UIButton *selectedBtn;

@property (nonatomic, strong) LLuShopGoodsCollectionView *collectionView;

@property (nonatomic, strong) NSMutableArray *hotDataList;

@property (nonatomic, assign) CGFloat collectionViewH;

@end

@implementation LLuShopGoodsViewController

- (NSMutableArray *)hotDataList {
    
    if (!_hotDataList) {
        
        _hotDataList = [NSMutableArray array];
    }
    return _hotDataList;
}

- (UIBarButtonItem *)backItem {
    
    if (!_backItem) {
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, 30, 30);
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(backToHome) forControlEvents:UIControlEventTouchUpInside];
        _backItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    }
    return _backItem;
}

- (LLuShopGoodsHeaderButtonView *)headerBtnView {
    
    if (!_headerBtnView) {
        
        _headerBtnView = [[LLuShopGoodsHeaderButtonView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 50)];
        [_headerBtnView.hotButton addTarget:self action:@selector(headerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_headerBtnView.priceButton addTarget:self action:@selector(headerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_headerBtnView.scoreButton addTarget:self action:@selector(headerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_headerBtnView.timeButton addTarget:self action:@selector(headerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        self.selectedBtn = _headerBtnView.hotButton;
        _headerBtnView.lineView.centerX = _headerBtnView.hotButton.centerX;
    }
    return _headerBtnView;
}

- (LLuShopGoodsCollectionView *)collectionView {
    
    if (!_collectionView) {
        
        _collectionView = [LLuShopGoodsCollectionView shopGoodsCollectionViewWithFrame:CGRectMake(0, 50, SCREEN_WIDTH, SCREEN_HEIGHT - 50)];
        _collectionView.contentSize = CGSizeMake(SCREEN_WIDTH, _collectionViewH);
    }
    return _collectionView;
}

- (void)setParameters:(NSMutableDictionary *)parameters {
    
    
    [parameters setObject:@"host" forKey:@"OrderName"];
    [parameters setObject:@"DESC" forKey:@"OrderType"];
    
    [parameters setObject:parameters[@"ID"] forKey:parameters[@"IDType"]];
    _parameters = parameters;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
    
    [self loadData];
}

- (void)initUI {
    
    self.view.backgroundColor = [UIColor whiteColor];

    //设置Nav的背景图
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    self.automaticallyAdjustsScrollViewInsets = NO;
    /**
     *  设置navigation的线
     */
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[[UIImage alloc] init]];
    
    //设置导航栏的半透明效果
    self.navigationController.navigationBar.translucent = NO;
    
    self.navigationItem.leftBarButtonItem = self.backItem;
    
    [self.view addSubview:self.headerBtnView];

}

- (void)loadData {
    
    [self getShopGoodsDataList];
}

- (void)getShopGoodsDataList {
    
    WS(weakSelf);
    [self.hotDataList removeAllObjects];

    if ([self.parameters[@"IDType"] isEqualToString:@"search"]) {
        
        
        [[HttpClient defaultClient] requestWithPath:self.parameters[@"url"] method:HttpRequestPost parameters:_parameters prepareExecute:^{
            
        } success:^(NSURLSessionDataTask *task, id responseObject) {
            
//            self.collectionView = nil;
            LLULog(@"successs");
            
            for (NSDictionary *dict in responseObject) {
                
                LLuShopGoods *shopGoods = [LLuShopGoods mj_objectWithKeyValues:dict];
                [self.hotDataList addObject:shopGoods];
            }
            weakSelf.collectionViewH = self.hotDataList.count * 320;
            [self.view addSubview:self.collectionView];
            self.collectionView.shopGoodsDataList = self.hotDataList;
            
            [self.collectionView reloadData];
            
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            
            
            LLULog(@"请求失败");
            LLULog(@"error--->%@", error);
        }];
    } else if ([self.parameters[@"IDType"] isEqualToString:@"GrouponId"]) {
        
        
        [[HttpClient defaultClient] requestWithPath:self.parameters[@"url"] method:HttpRequestGet parameters:_parameters prepareExecute:^{
            
        } success:^(NSURLSessionDataTask *task, id responseObject) {
            
            //            self.collectionView = nil;
            LLULog(@"successs");
            
            for (NSDictionary *dict in responseObject) {
                
                LLuShopGoods *shopGoods = [LLuShopGoods mj_objectWithKeyValues:dict];
                [self.hotDataList addObject:shopGoods];
            }
            weakSelf.collectionViewH = self.hotDataList.count * 320;
            [self.view addSubview:self.collectionView];
            self.collectionView.shopGoodsDataList = self.hotDataList;
            
            [self.collectionView reloadData];
            
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            
            
            LLULog(@"请求失败");
            LLULog(@"error--->%@", error);
        }];
        
    }  else {
        
        [[HttpClient defaultClient] requestWithPath:self.parameters[@"url"] method:HttpRequestGet parameters:_parameters prepareExecute:^{
            
        } success:^(NSURLSessionDataTask *task, id responseObject) {
        
//            self.collectionView = nil;
            LLULog(@"successs");
            
            for (NSDictionary *dict in responseObject) {
                
                LLuShopGoods *shopGoods = [LLuShopGoods mj_objectWithKeyValues:dict];
                [self.hotDataList addObject:shopGoods];
            }
            weakSelf.collectionViewH = self.hotDataList.count * 320;
            [self.view addSubview:self.collectionView];
            self.collectionView.shopGoodsDataList = self.hotDataList;
            
            [self.collectionView reloadData];
            
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            
            
            LLULog(@"请求失败");
            LLULog(@"error--->%@", error);
        }];
    }
}

- (void)backToHome {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    LLULog(@"PoP to Home");
}

- (void)headerBtnClick:(UIButton *)button {

    
    NSInteger btnType = button.tag - 1000;
    
    NSArray * orderNameList = @[@"host",@"price",@"time",@"score"];
    NSArray * orderTypeList = @[@"DESC",@"DESC",@"ASC",@"DESC"];
    if (button != self.selectedBtn) {
        
        button.selected = YES;
        self.selectedBtn.selected = NO;
        self.selectedBtn = button;
        
        [UIView animateWithDuration:0.3 animations:^{
            
            _headerBtnView.lineView.centerX = button.centerX;
        } completion:^(BOOL finished) {
            
            [self.parameters setObject:orderNameList[btnType] forKey:@"OrderName"];
            [self.parameters setObject:orderTypeList[btnType] forKey:@"OrderType"];
            
            [self getShopGoodsDataList];
        }];
        



        [self.collectionView reloadData];
        
    }
}
//- (void)headerBtnClick:(UIButton *)sender {
//    
//    [self.collectionView reloadData];
//    if (sender == _headerBtnView.hotButton) {
//        
//        _headerBtnView.hotButton.selected = YES;
//        _headerBtnView.priceButton.selected = NO;
//        _headerBtnView.scoreButton.selected = NO;
//        _headerBtnView.timeButton.selected = NO;
//        
//        [UIView animateWithDuration:0.35 animations:^{
//            
//            _headerBtnView.lineView.centerX = _headerBtnView.hotButton.centerX;
// 
//        } completion:^(BOOL finished) {
//
//        [self.parameters setValue:@"host" forKey:@"OrderName"];
//            
////            self.parameters = @{@"ShopId":self.ShopId,
////                                @"OrderName": @"host",
////                                @"OrderType": @"DESC"};
////            [self getShopGoodsDataList];
//        }];
//        
//    } else if (sender == _headerBtnView.priceButton) {
//        
//        _headerBtnView.hotButton.selected = NO;
//        _headerBtnView.priceButton.selected = YES;
//        _headerBtnView.scoreButton.selected = NO;
//        _headerBtnView.timeButton.selected = NO;
//        
//        [UIView animateWithDuration:0.35 animations:^{
//            
//            _headerBtnView.lineView.centerX = _headerBtnView.priceButton.centerX;
//
//        } completion:^(BOOL finished) {
//            
////        [self.parameters setValue:@"price" forKey:@"OrderName"];
////
////            self.parameters = @{@"ShopId":self.ShopId,
////                                @"OrderName": @"price",
////                                @"OrderType": @"DESC"};
////            [self getShopGoodsDataList];
//            
//        }];
//
//    } else if (sender == _headerBtnView.scoreButton) {
//        
//        _headerBtnView.hotButton.selected = NO;
//        _headerBtnView.priceButton.selected = NO;
//        _headerBtnView.scoreButton.selected = YES;
//        _headerBtnView.timeButton.selected = NO;
//        
//        [UIView animateWithDuration:0.35 animations:^{
//
//            _headerBtnView.lineView.centerX = _headerBtnView.scoreButton.centerX;
//            
//        } completion:^(BOOL finished) {
//            
////            [self.parameters setValue:@"score" forKey:@"OrderName"];
//
////            self.parameters = @{@"ShopId":self.ShopId,
////                                @"OrderName": @"score",
////                                @"OrderType": @"DESC"};
////            [self getShopGoodsDataList];
//        }];
//
//    } else if (sender == _headerBtnView.timeButton) {
//        
//        _headerBtnView.hotButton.selected = NO;
//        _headerBtnView.priceButton.selected = NO;
//        _headerBtnView.scoreButton.selected = NO;
//        _headerBtnView.timeButton.selected = YES;
//        
//        [UIView animateWithDuration:0.35 animations:^{
//           
//            _headerBtnView.lineView.centerX = _headerBtnView.timeButton.centerX;
//            
//        } completion:^(BOOL finished) {
//            
////            [self.parameters setValue:@"time" forKey:@"OrderName"];
////            [self.parameters setValue:@"ASC" forKey:@"OrderName"];
//
//            
////            self.parameters = @{@"ShopId":self.ShopId,
////                                @"OrderName": @"time",
////                                @"OrderType": @"ASC"};
//////            [self getShopGoodsDataList];
//        }];
//    }
//    [self getShopGoodsDataList];
//
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
