//
//  LLuShopGoodsViewController.h
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLuShopGoodsViewController : UIViewController

/**品牌ID*/
@property (copy, nonatomic) NSString *ShopId;

@property (nonatomic, strong) NSMutableDictionary *parameters;

@end
