//
//  LLuGoodsDetailsNavController.m
//  有面儿App
//
//  Created by ma c on 16/4/7.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuGoodsDetailsNavController.h"
#import "UMSocial.h"

@interface LLuGoodsDetailsNavController () <UMSocialUIDelegate>

@property (nonatomic, strong) UIBarButtonItem *backItem;

@property (nonatomic, strong) UIBarButtonItem *shareItem;

@property (nonatomic, strong) UIBarButtonItem *collectItem;

@end

@implementation LLuGoodsDetailsNavController

- (UIBarButtonItem *)backItem {
    
    if (!_backItem) {
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, 30, 30);
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(backToHome) forControlEvents:UIControlEventTouchUpInside];
        _backItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    }
    return _backItem;
}

- (UIBarButtonItem *)shareItem {
    
    if (!_shareItem) {
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, 30, 30);
        [button setImage:[UIImage imageNamed:@"详情界面转发按钮"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"详情界面转发按钮"] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(shareAction) forControlEvents:UIControlEventTouchUpInside];
        _shareItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    }
    return _shareItem;
}

- (UIBarButtonItem *)collectItem {
    
    if (!_collectItem) {
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, 30, 30);
        [button setImage:[UIImage imageNamed:@"详情界面收藏按钮"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"详情界面收藏按钮"] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(collectionAction) forControlEvents:UIControlEventTouchUpInside];
        _collectItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    }
    return _collectItem;
}

- (void)backToHome {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    LLULog(@"PoP to Home");
}

- (void)shareAction {
    
    LLULog(@"share");
    
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:@"570dea4567e58e71800016ec"
                                      shareText:@"友盟社会化分享让您快速实现分享等社会化功能测试，http://umeng.com/social"
                                     shareImage:[UIImage imageNamed:@"icon.png"]
                                shareToSnsNames:@[UMShareToSina]
                                       delegate:self];
    
}

//实现回调方法（可选）：
-(void)didFinishGetUMSocialDataInViewController:(UMSocialResponseEntity *)response
{
    //根据`responseCode`得到发送结果,如果分享成功
    if(response.responseCode == UMSResponseCodeSuccess)
    {
        //得到分享到的微博平台名
        NSLog(@"share to sns name is %@",[[response.data allKeys] objectAtIndex:0]);
    }
}

- (void)collectionAction {
    
    LLULog(@"collection");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置导航栏的半透明效果
    self.navigationBar.translucent = NO;
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    //设置Nav的背景图
    [viewController.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    viewController.automaticallyAdjustsScrollViewInsets = NO;
    /**
     *  设置navigation的线
     */
    [viewController.navigationController.navigationBar setShadowImage:[[UIImage alloc] init]];

    viewController.navigationItem.leftBarButtonItem = self.backItem;
    viewController.navigationItem.rightBarButtonItems = @[self.collectItem, self.shareItem];
    [super pushViewController:viewController animated:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
