//
//  LLuLimitSaleViewController.m
//  有面儿
//
//  Created by ma c on 16/4/5.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuLimitSaleViewController.h"
#import "LLuBanner.h"
#import "LLuBannerGroup.h"
#import "LLuNewsGroup.h"
#import "LLuBrandGroup.h"
#import "LLuTableViewHeaderSectionView.h"
#import "LLuNewsGroupTableView.h"
#import "LLuBrandGroupTableView.h"
#import "SearchResultController.h"
#import "LLuGoodsDetailsViewController.h"
#import "LLuGoodsDetailsNavController.h"
#import "LLuSearchViewController.h"
#import "LLuShopGoodsViewController.h"

static NSString *cellID = @"UITableViewCell";
@interface LLuLimitSaleViewController () <LLuBannerViewDelegate, LLuChildTableViewCellDelegate,UITableViewDataSource, UITableViewDelegate>

//Banner数据
@property (nonatomic, strong) NSMutableArray *bannerDataList;
@property (nonatomic, strong) LLuBannerView *bannerView;

@property (nonatomic, strong) NSMutableArray *bannerGroupIDList;
//Banner广告页数据
@property (nonatomic, strong) NSMutableArray *bannerGroupImage;

@property (nonatomic, strong) UITableView *tableView;

//新品团购数据
@property (nonatomic, strong) NSMutableArray *newsGroupDataList;
//团购数据
@property (nonatomic, strong) NSMutableArray *brandGroupDataList;

@property (nonatomic, strong) LLuNewsGroupTableView *newsGroupTableView;

@property (nonatomic, strong) LLuBrandGroupTableView *brandGroupTableView;

@property (nonatomic, strong) LLuTableViewHeaderSectionView *headerSectionView;

@end

@implementation LLuLimitSaleViewController

#pragma mark - setter and getter

- (NSMutableArray *)bannerDataList {
    
    if (!_bannerDataList) {
        
        _bannerDataList = [NSMutableArray array];
    }
    return _bannerDataList;
}

- (NSMutableArray *)bannerGroupIDList {
    
    if (!_bannerGroupIDList) {
        
        _bannerGroupIDList = [NSMutableArray array];
    }
    return _bannerGroupIDList;
}

- (NSMutableArray *)newsGroupDataList {
    
    if (!_newsGroupDataList) {
        
        _newsGroupDataList = [NSMutableArray array];
    }
    return _newsGroupDataList;
}

- (NSMutableArray *)brandGroupDataList {
    
    if (!_brandGroupDataList) {
        
        _brandGroupDataList = [NSMutableArray array];
    }
    return _brandGroupDataList;
}

- (NSMutableArray *)bannerGroupImage {
    
    if (!_bannerGroupImage) {
        
        _bannerGroupImage = [NSMutableArray array];
    }
    return _bannerGroupImage;
}

- (LLuBannerView *)bannerView {
    
    if (!_bannerView) {
        
        _bannerView = [LLuBannerView bannerView];
        _bannerView.backgroundColor = [UIColor grayColor];
        _bannerView.placeholderImageName = @"注册界面下一步按钮";
        _bannerView.delegate = self;
    }
    return _bannerView;
}

- (LLuTableViewHeaderSectionView *)headerSectionView {
    
    if (!_headerSectionView) {
        
        _headerSectionView = [[LLuTableViewHeaderSectionView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 50)];
        [_headerSectionView.newsGroupBtn addTarget:self action:@selector(btnSelected:) forControlEvents:UIControlEventTouchUpInside];
        [_headerSectionView.brandGroupBtn addTarget:self action:@selector(btnSelected:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _headerSectionView;
}

- (LLuNewsGroupTableView *)newsGroupTableView {
    
    if (!_newsGroupTableView) {
        
        _newsGroupTableView = [[LLuNewsGroupTableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 0) style:UITableViewStylePlain];
        _newsGroupTableView.childTableViewDelegate = self;
    }
    return _newsGroupTableView;
}

- (LLuBrandGroupTableView *)brandGroupTableView {
    
    if (!_brandGroupTableView) {
        
        _brandGroupTableView = [[LLuBrandGroupTableView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH, 0, SCREEN_WIDTH, 0) style:UITableViewStylePlain];
        _brandGroupTableView.childTableViewDelegate = self;
    }
    return _brandGroupTableView;
}

- (UITableView *)tableView {
    
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableHeaderView = self.bannerView;
        _tableView.sectionHeaderHeight = 50;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
    }
    return _tableView;
}

- (void)btnSelected:(UIButton *)btn {
    
    [_newsGroupTableView reloadData];
    
    [_tableView reloadData];
    
    if (btn == _headerSectionView.newsGroupBtn) {
        _headerSectionView.newsGroupBtn.selected = YES;
        _headerSectionView.brandGroupBtn.selected = NO;
        [_newsGroupTableView reloadData];
        _tableView.rowHeight = _newsGroupDataList.count * 173 + 88;
        [_tableView reloadData];

        [UIView animateWithDuration:0.5 animations:^{
            CGRect newsGroupRect = _newsGroupTableView.frame;
            newsGroupRect.origin.x = 0;
            _newsGroupTableView.frame = newsGroupRect;
            
            CGRect groupRect = _brandGroupTableView.frame;
            groupRect.origin.x = SCREEN_WIDTH;
            _brandGroupTableView.frame = groupRect;
        }];
        
    }  else if (btn == _headerSectionView.brandGroupBtn) {
        
        _headerSectionView.newsGroupBtn.selected = NO;
        _headerSectionView.brandGroupBtn.selected = YES;
        [_brandGroupTableView reloadData];
        _tableView.rowHeight = _brandGroupDataList.count * 185 + 88;
        [_tableView reloadData];
        
        
        [UIView animateWithDuration:0.5 animations:^{
            CGRect newsGroupRect = _newsGroupTableView.frame;
            newsGroupRect.origin.x = -SCREEN_WIDTH;
            _newsGroupTableView.frame = newsGroupRect;
            
            CGRect groupRect = _brandGroupTableView.frame;
            groupRect.origin.x = 0;
            _brandGroupTableView.frame = groupRect;
        }];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    [cell.contentView addSubview:self.newsGroupTableView];
    [cell.contentView addSubview:self.brandGroupTableView];
    
    UIView *view_bg = [[UIView alloc]initWithFrame:cell.frame];
    
    view_bg.backgroundColor = [UIColor clearColor];
    
    cell.selectedBackgroundView = view_bg;
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    return self.headerSectionView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_headerSectionView.newsGroupBtn.selected) {
        
        _newsGroupTableView.height = _newsGroupDataList.count * 173 + 88;
        _brandGroupTableView.height = _brandGroupDataList.count * 185 + 88;
        return _newsGroupDataList.count * 173 + 88;
    } else {
        
        _newsGroupTableView.height = _newsGroupDataList.count * 173 + 88;
        _brandGroupTableView.height = _brandGroupDataList.count * 185 + 88;
        return _brandGroupDataList.count * 185 + 88;
    }
}

//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    
//    [tableView deselectRowAtIndexPath:indexPath animated:NO];
//    LLuGoodsDetailsViewController *goodsDetailVC = [[LLuGoodsDetailsViewController alloc] init];
//    LLuGoodsDetailsNavController *Nav = [[LLuGoodsDetailsNavController alloc] initWithRootViewController:goodsDetailVC];
//    
//    [self presentViewController:Nav animated:YES completion:nil];
//}

- (void)getModelData {
    
    [self getBannerImageListData];
    [self getSearchGroupImageListDataWithBannerRelatedId];
    [self getNewsGroupDataList];
    [self getBrandGroupDataList];
    
}

- (void)initUI {
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.translucent = NO;
    NSString *title = @"限时特卖";
    NSDictionary *dict = @{NSFontAttributeName:[UIFont systemFontOfSize:20]};
    NSMutableAttributedString *attTitle = [[NSMutableAttributedString alloc] initWithString:title attributes:dict];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, 30)];
    titleLabel.attributedText = attTitle;
    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithNormalImage:@"限时特卖界面搜索按钮" highlightedImage:@"限时特卖界面搜索按钮" target:self action:@selector(searchClcik)];
    
    [self.view addSubview:self.tableView];
}

#pragma mark life ctyle

- (void)viewDidLoad {
    [super viewDidLoad];

    [self initUI];
    [self getModelData];
}


#pragma mark - 设置cell分割线
- (void)viewDidLayoutSubviews {
    
    if ([self.tableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.tableView setSeparatorInset:UIEdgeInsetsMake(0,0,0,0)];
    }
    
    if ([self.tableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [self.tableView setLayoutMargins:UIEdgeInsetsMake(0,0,0,0)];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

#pragma make 获取Banner数据

- (void)getBannerImageListData {
    
    NSString *urlString = @"appHome/appHome.do";
    
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestGet parameters:nil prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
//        LLULog(@"successs");
        
        NSArray *dataArray = responseObject;
        
        for (NSDictionary *dict in dataArray) {
            
            LLuBanner *banner = [LLuBanner mj_objectWithKeyValues:dict];
            
            
            //            [self getBann erGroupImageListDataWithBannerRelatedId:banner];
            
            
            
            
            
            NSURL *url = [NSURL URLWithString:banner.ImgView];
            [self.bannerDataList addObject:url];
        }
        self.bannerView.imageUrls = self.bannerDataList;
        [self.tableView reloadData];
        
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}

- (void)getBannerGroupImageListDataWithBannerRelatedId:(LLuBanner *)banner {
    
    NSString *urlString = @"appGgroupon/findGrouponMiddleList.do";
    NSDictionary *parameters = @{@"GrouponId":banner.RelatedId};
    
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestPost parameters:parameters prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        LLuBannerGroup *group = [LLuBannerGroup mj_objectWithKeyValues:responseObject[0]];
        
        [self.bannerGroupImage addObject:group.ImgView];
        
        self.bannerView.GroupImageUrls = self.bannerGroupImage;
        [self.tableView reloadData];
        
        LLULog(@"self.bannerGroupImage===========%@", self.bannerGroupImage);
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}

- (void)getSearchGroupImageListDataWithBannerRelatedId {
    
    NSString *urlString = @"appGgroupon/appGrounpGoodsList.do";
    NSDictionary *parameters = @{
                                 @"OrderName":@"host",
                                 @"OrderType":@"DESC"};
    
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestPost parameters:parameters prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {

        [self.tableView reloadData];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}

#pragma mark - 获取新品团购数据
- (void)getNewsGroupDataList {
    WS(weakSelf);
    
    NSString *urlString = @"appActivity/appHomeGoodsList.do";
    
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestGet parameters:nil prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSArray *dataArray = responseObject;
        
        for (NSDictionary *dict in dataArray) {
            
            LLuNewsGroup *newsGroup = [LLuNewsGroup mj_objectWithKeyValues:dict];
            
            [self.newsGroupDataList addObject:newsGroup];
        }
        
        _newsGroupTableView.newsGroupDataList = self.newsGroupDataList;

        [weakSelf.newsGroupTableView reloadData];
        [weakSelf.tableView reloadData];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}

#pragma mark 获取团购数据
- (void)getBrandGroupDataList {
    WS(weakSelf);
    
    NSString *urlString = @"appActivity/appActivityList.do";
    
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestGet parameters:nil prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSArray *dataArray = responseObject;
        
        for (NSDictionary *dict in dataArray) {
            
            LLuBrandGroup *brandGroup = [LLuBrandGroup mj_objectWithKeyValues:dict];
            
            [self.brandGroupDataList addObject:brandGroup];
        }
        _brandGroupTableView.brandGroupDataList = self.brandGroupDataList;
        [weakSelf.tableView reloadData];
        [weakSelf.brandGroupTableView reloadData];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}


- (void)searchClcik {
    
    LLuSearchViewController *sc = [[LLuSearchViewController alloc] init];
    UINavigationController *scNav = [[UINavigationController alloc] initWithRootViewController:sc];

    //使用模态视图跳转到搜索控制器
    [self presentViewController:scNav animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


#pragma mark LLuBannerViewDelegate Method

- (void)bannerView:(LLuBannerView *)bannerView imageDidClickWithIndex:(NSInteger)imageIndex {
    
    LLULog(@"第%ld张图片被选中了！", imageIndex);
    
    LLuGoodsDetailsViewController *goodsDetailVC = [[LLuGoodsDetailsViewController alloc] init];
    LLuGoodsDetailsNavController *Nav = [[LLuGoodsDetailsNavController alloc] initWithRootViewController:goodsDetailVC];
    
    [self presentViewController:Nav animated:YES completion:nil];
}

#pragma mark - LLuChildTableViewCellDelegate Method
- (void)childTableView:(UITableView *)childTableView CellDidClickWithIndexPath:(NSInteger)childTableViewIndexRow {
    
    if (childTableView == _newsGroupTableView) {
        
        LLuGoodsDetailsViewController *goodsDetailVC = [[LLuGoodsDetailsViewController alloc] init];
        
        LLuNewsGroup *newsGroup = self.newsGroupDataList[childTableViewIndexRow];
        goodsDetailVC.goodsBannerID = newsGroup.GoodsId;
        goodsDetailVC.parameters = @{@"GoodsId":newsGroup.GoodsId};
        
        LLuGoodsDetailsNavController *Nav = [[LLuGoodsDetailsNavController alloc] initWithRootViewController:goodsDetailVC];
        
        [self presentViewController:Nav animated:YES completion:nil];
        
        [self.newsGroupTableView reloadData];
        
        
    } else if (childTableView == _brandGroupTableView) {
        
        LLuShopGoodsViewController *shopGoodsVC = [[LLuShopGoodsViewController alloc] init];
        
        LLuBrandGroup *brandGroup = self.brandGroupDataList[childTableViewIndexRow];

        shopGoodsVC.title = brandGroup.ShopTitle;
        
        NSDictionary * parameters = @{
                                      @"url" : @"appGgroupon/appGrounpGoodsList.do",
                                      @"IDType" : @"GrouponId",
                                      @"ID" : brandGroup.ActivityId
                                      };
        shopGoodsVC.parameters = [NSMutableDictionary dictionaryWithDictionary:parameters];
        UINavigationController *Nav = [[UINavigationController alloc] initWithRootViewController:shopGoodsVC];
        
        [self presentViewController:Nav animated:YES completion:nil];
        [self.brandGroupTableView reloadData];
    }

}

@end
