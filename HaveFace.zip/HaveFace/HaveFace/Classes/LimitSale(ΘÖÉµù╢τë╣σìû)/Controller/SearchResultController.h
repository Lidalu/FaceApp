//
//  SearchResultController.h
//  UISearchController详解
//
//  Created by ma c on 3/2/16.
//  Copyright © 2016 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchResultController : UITableViewController

@property (nonatomic, copy) NSString *searchText;

@property (nonatomic, strong) NSArray *searchResults;

- (void)searchBarText:(NSString *)searchBarTextString;

@end
