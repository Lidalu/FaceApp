//
//  SearchResultController.m
//  UISearchController详解
//
//  Created by ma c on 3/2/16.
//  Copyright © 2016 lu. All rights reserved.
//

#import "SearchResultController.h"
//#import "LLuFriendCell.h"
//#import "LLuFriend.h"
//#import "LLuFriendsGroup.h"

@interface SearchResultController ()  

@property (nonatomic, strong) NSString *searchString;

@end

@implementation SearchResultController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//#warning Incomplete implementation, return the number of rows
    return self.searchResults.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"cellID";
//    LLuFriendCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
//    if (!cell) {
//        
//        cell = [[LLuFriendCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
//    }
//    
//    LLuFriend *friend = self.searchResults[indexPath.row];
//    cell.searchString = self.searchString;
//    cell.mutableFriends = friend;

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}


- (void)searchBarText:(NSString *)searchBarTextString {
    
    self.searchString = searchBarTextString;
}

@end
