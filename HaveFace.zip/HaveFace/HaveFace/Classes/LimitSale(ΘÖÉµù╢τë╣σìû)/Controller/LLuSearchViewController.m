//
//  LLuSearchViewController.m
//  Face_App
//
//  Created by ma c on 16/4/14.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuSearchViewController.h"
#import "LLuShopGoodsViewController.h"

@interface LLuSearchViewController () <UISearchBarDelegate>

@property (nonatomic, strong) LLuShopGoodsViewController *shopGoodsVC;

@property (nonatomic, strong) UISearchBar *searchBar;

@property (nonatomic, strong) UISearchController *searchVc;

@property (nonatomic, strong) UIBarButtonItem *backItem;

@end

@implementation LLuSearchViewController

- (LLuShopGoodsViewController *)shopGoodsVC {
    
    if (!_shopGoodsVC) {
        
        _shopGoodsVC = [[LLuShopGoodsViewController alloc] init];
    }
    return _shopGoodsVC;
}

- (UIBarButtonItem *)backItem {
    
    if (!_backItem) {
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, 30, 30);
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(backToHome) forControlEvents:UIControlEventTouchUpInside];
        _backItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    }
    return _backItem;
}

- (UISearchBar *)searchBar {
    
    if (!_searchBar) {
        
        _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(20, 0, SCREEN_WIDTH - 70, 44)];
        _searchBar.placeholder = @"搜索";
        _searchBar.tintColor = [UIColor whiteColor];
//        _searchBar.showsCancelButton = YES;
        _searchBar.delegate = self;
    }
    return _searchBar;
}

- (void)initUI {
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barTintColor = [UIColor grayColor];
    self.navigationController.navigationBar.translucent = NO;
    self.navigationItem.titleView = self.searchBar;
    self.navigationItem.leftBarButtonItem = self.backItem;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    
    NSString *searchTerm = searchBar.text;
    NSDictionary * params = @{
                              @"url" : @"appSearch/searchList.do",
                              @"IDType" : @"search",
                              @"ID" : searchTerm
                              };
    
    self.shopGoodsVC.parameters = [NSMutableDictionary dictionaryWithDictionary:params];
    
    UINavigationController *Nav = [[UINavigationController alloc] initWithRootViewController:_shopGoodsVC];

    [self presentViewController:Nav animated:YES completion:nil];
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {

    self.searchBar.showsCancelButton = YES;
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
    
    self.searchBar.showsCancelButton = NO;
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    
    self.searchBar.text = NULL;
    [self.searchBar endEditing:YES];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    self.searchBar.text = NULL;
    [self.searchBar endEditing:YES];
}

- (void)backToHome {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    LLULog(@"PoP to Home");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
