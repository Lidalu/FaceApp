//
//  LLuChildTableViewCellDelegate.h
//  Face_App
//
//  Created by ma c on 16/4/7.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol LLuChildTableViewCellDelegate <NSObject>
/**
 *  点击cell后的回调
 */

@optional
- (void)childTableView:(UITableView *)childTableView CellDidClickWithIndexPath:(NSInteger)childTableViewIndexRow;

@end
