//
//  LLuGoodsDetailsViewController.h
//  有面儿App
//
//  Created by ma c on 16/4/7.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLuGoodsDetailsViewController : UIViewController

@property (nonatomic, strong) NSDictionary *parameters;

//商品图片列表ID
@property (nonatomic, strong) NSString *goodsBannerID;



@end
