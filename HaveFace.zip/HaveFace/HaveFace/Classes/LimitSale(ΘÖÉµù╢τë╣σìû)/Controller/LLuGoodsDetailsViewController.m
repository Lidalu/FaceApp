//
//  LLuGoodsDetailsViewController.m
//  有面儿App
//
//  Created by ma c on 16/4/7.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuGoodsDetailsViewController.h"
#import "LLuGoodsDetailView.h"
#import "LLuGoodsDetailBanner.h"
#import "LLuGoodsDetail.h"
#import "LLuGoodsDetailIMageAndText.h"
#import "LLuGoodsDetailIMageAndTextView.h"
#import "LLuGoodsDetailImageView.h"
#import "LLuGoodsDetailBrandView.h"
#import "LLuShopGoodsViewController.h"

static NSString *cellID = @"cellID";

@interface LLuGoodsDetailsViewController () <LLuBannerViewDelegate, UIScrollViewDelegate>

@property (nonatomic, strong) UIScrollView *scrollView;

//商品图片（可轮播，可单一）
@property (nonatomic, strong) LLuBannerView *bannerView;

//商品图片数据
@property (nonatomic, strong) NSMutableArray *goodsDetailBannerImageList;

//商品详情部分（包含价格，评分等）
@property (nonatomic, strong) NSMutableArray *goodsDetailDataList;
//图文详情数据
@property (nonatomic, strong) NSMutableArray *goodsDetailImgAndTextList;

@property (nonatomic, strong) UIView *toolBar;

@property (nonatomic, strong) LLuGoodsDetailView *goodsDetailView;

@property (nonatomic, strong) LLuGoodsDetailIMageAndTextView *goodsDetailIMageAndTextView;

@property (nonatomic, strong) LLuGoodsDetailImageView *goodsDetailImageView;

@property (nonatomic, strong) LLuGoodsDetailBrandView *goodsDetailBrandView;

//@property (nonatomic, strong) UIView *contentView;

@property (nonatomic, strong) NSMutableArray *goodsImageDataList;

@property (nonatomic, assign) CGFloat bannerViewH;

@property (nonatomic, assign) CGFloat imageViewH;

@property (nonatomic, assign) CGFloat imageAndTextViewH;

@end

@implementation LLuGoodsDetailsViewController

#pragma mark - setter and getter

- (NSMutableArray *)goodsImageDataList {
    
    if (!_goodsImageDataList) {
        
        _goodsImageDataList = [NSMutableArray array];
    }
    return _goodsImageDataList;
}

- (NSMutableArray *)goodsDetailBannerImageList {
    
    if (!_goodsDetailBannerImageList) {
        
        _goodsDetailBannerImageList = [NSMutableArray array];
    }
    return _goodsDetailBannerImageList;
}

- (NSMutableArray *)goodsDetailDataList {
    
    if (!_goodsDetailDataList) {
        
        _goodsDetailDataList = [NSMutableArray array];
    }
    return _goodsDetailDataList;
}

- (NSMutableArray *)goodsDetailImgAndTextList {
    
    if (!_goodsDetailImgAndTextList) {
        
        _goodsDetailImgAndTextList = [NSMutableArray array];
    }
    return _goodsDetailImgAndTextList;
}

//- (UIView *)contentView {
//    
//    if (!_contentView) {
//
//        _contentView = [[UIView alloc] initWithFrame:self.view.bounds];
//        _contentView.backgroundColor = [UIColor cyanColor];
//    }
//    return _contentView;
//}

- (UIScrollView *)scrollView {
    
    if (!_scrollView) {
        
        
        _scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.delegate = self;
        _scrollView.backgroundColor = [UIColor whiteColor];
//        [_scrollView addSubview:self.goodsDetailBrandView];

//        [_scrollView addSubview:self.contentView];
    }
    return _scrollView;
}

- (LLuBannerView *)bannerView {
    
    if (!_bannerView) {
        
        _bannerView = [LLuBannerView bannerView];
        _bannerView.backgroundColor = [UIColor grayColor];
        _bannerView.placeholderImageName = @"nav_backImage";
        
        _bannerView.delegate = self;
    }
    return _bannerView;
}

- (UIView *)toolBar {
    
    if (!_toolBar) {
        
        _toolBar = [[UIView alloc] init];
        _toolBar.backgroundColor = [UIColor whiteColor];
        
        UIButton *firstBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_toolBar addSubview:firstBtn];
        UIImage *image1 = [UIImage imageNamed:@"详情界面购物车按钮"];
        CGSize size1 = image1.size;
        firstBtn.size = size1;
        [firstBtn setImage:image1 forState:UIControlStateNormal];
        [firstBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(_toolBar.mas_left).offset(18.0f);
            make.centerY.equalTo(_toolBar.centerY);
        }];
        
        UIButton *secondBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_toolBar addSubview:secondBtn];
        UIImage *image2 = [UIImage imageNamed:@"详情界面加入购物车按钮"];
        CGSize size2 = image2.size;
        secondBtn.size = size2;
        [secondBtn setImage:image2 forState:UIControlStateNormal];
        [secondBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(firstBtn.mas_right).offset(40.0f);
            make.centerY.equalTo(_toolBar.centerY);
        }];
        
        UIButton *thirdBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_toolBar addSubview:thirdBtn];
        UIImage *image3 = [UIImage imageNamed:@"详情界面立即购买按钮"];
        CGSize size3 = image3.size;
        thirdBtn.size = size3;
        [thirdBtn setImage:image3 forState:UIControlStateNormal];
        [thirdBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.right.equalTo(_toolBar.mas_right).offset(-20.0f);
            make.centerY.equalTo(_toolBar.centerY);
        }];
    }
    return _toolBar;
}

- (LLuGoodsDetailView *)goodsDetailView {
    
    if (!_goodsDetailView) {
        
        _goodsDetailView = [[LLuGoodsDetailView alloc] initWithFrame:CGRectMake(0, 200, SCREEN_WIDTH, 240)];
    }

    return _goodsDetailView;
}

- (LLuGoodsDetailIMageAndTextView *)goodsDetailIMageAndTextView {
    
    if (!_goodsDetailIMageAndTextView) {
     
//        NSLog(@"imageAndTextViewH===%lf", self.imageAndTextViewH);

        _goodsDetailIMageAndTextView = [[LLuGoodsDetailIMageAndTextView alloc] initWithFrame:CGRectMake(0, 610, SCREEN_WIDTH, _imageAndTextViewH)];
    }

    return _goodsDetailIMageAndTextView;
}

- (LLuGoodsDetailImageView *)goodsDetailImageView {
    
    if (!_goodsDetailImageView) {
//        NSLog(@"imageViewH===%lf", self.imageViewH);

        _goodsDetailImageView = [[LLuGoodsDetailImageView alloc] initWithFrame:CGRectMake(0, 810, SCREEN_WIDTH, _imageViewH)];
//        NSLog(@"imageViewH===%lf", self.imageViewH);

    }

    return _goodsDetailImageView;
}

- (LLuGoodsDetailBrandView *)goodsDetailBrandView {
    
    if (!_goodsDetailBrandView) {
        
        _goodsDetailBrandView = [[LLuGoodsDetailBrandView alloc] initWithFrame:CGRectMake(0, 440, SCREEN_WIDTH, 170)];
        [_goodsDetailBrandView.whiteButton addTarget:self action:@selector(SameBrandGoods) forControlEvents:UIControlEventTouchUpInside];
    }
    return _goodsDetailBrandView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadData];
    [self initUI];

}

- (void)initUI {
    
    self.view.backgroundColor = [UIColor whiteColor];

    [self.view addSubview:self.scrollView];
    [self.view addSubview:self.toolBar];
}

- (void)loadData {
    
    [self getGoodsDetailImageList];
    [self getGoodsDetailDataList];
    [self getGoodsDetailImageDataList];
    [self getGoodsDetailImageAndTextDataList];
}

//获取商品数据
- (void)getGoodsDetailImageList {
    
    NSString *urlString = @"appGoods/findGoodsImgList.do";
    
//    NSDictionary *parameters = @{@"GoodsId":self.goodsBannerID};
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestGet parameters:_parameters prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        LLULog(@"successs");
        
        NSArray *dataArray = responseObject;
        
        for (NSDictionary *dict in dataArray) {
            
            LLuGoodsDetailBanner *goodsDetailBanner = [LLuGoodsDetailBanner mj_objectWithKeyValues:dict];
            
            if ([goodsDetailBanner.ImgType isEqualToString:@"1"]) {
                
                NSURL *url = [NSURL URLWithString:goodsDetailBanner.ImgView];
                [self.goodsDetailBannerImageList addObject:url];
                self.bannerViewH = [goodsDetailBanner.Resolution floatValue] / 2.0f;
            }
        }
        [self.scrollView addSubview:self.bannerView];
        self.bannerView.imageUrls = self.goodsDetailBannerImageList;
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
    
}

- (void)getGoodsDetailDataList {
    
//    http://123.57.141.249:8080/beautalk/appGoods/findGoodsDetail.do
    NSString *urlString = @"appGoods/findGoodsDetail.do";
    
    
//    WS(weakSelf);
//    NSDictionary *parameters = @{@"GoodsId":self.goodsBannerID};
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestGet parameters:_parameters prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        LLULog(@"successs");
        
        LLuGoodsDetail *goodsDetail = [LLuGoodsDetail mj_objectWithKeyValues:responseObject];

        [self.scrollView addSubview:self.goodsDetailView];
        self.goodsDetailView.goodsDetail = goodsDetail;
        [self.scrollView addSubview:self.goodsDetailBrandView];
        self.goodsDetailBrandView.goodsDetail = goodsDetail;
        
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}

- (void)getGoodsDetailImageDataList {
    
    
    NSString *urlString = @"appGoods/findGoodsImgList.do";
//    WS(weakSelf);
//    NSDictionary *parameters = @{@"GoodsId":self.goodsBannerID};
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestGet parameters:_parameters prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        LLULog(@"successs");
        
        NSArray *dataArray = responseObject;
        
        for (NSDictionary *dict in dataArray) {
            
            LLuGoodsDetailBanner *goodsDetailBanner = [LLuGoodsDetailBanner mj_objectWithKeyValues:dict];
            
            if ([goodsDetailBanner.ImgType isEqualToString:@"2"] || [goodsDetailBanner.ImgType isEqualToString:@"3"]) {

                CGFloat imageHeight = [goodsDetailBanner.Resolution floatValue]*(SCREEN_WIDTH/[goodsDetailBanner.Resolution floatValue]);

                self.imageViewH += imageHeight;
                [self.goodsImageDataList addObject:goodsDetailBanner];

            }
        }
        
        [self.scrollView addSubview:self.goodsDetailImageView];
        self.goodsDetailImageView.goodsDetailImageDataList = self.goodsImageDataList;

//        NSLog(@"imageViewH===%lf", self.imageViewH);

        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
    
}

#pragma mark - 获取图文详情数据
- (void)getGoodsDetailImageAndTextDataList {
//    http://123.57.141.249:8080/beautalk/appGoods/findGoodsDetailList.do
    
    WS(weakSelf);
    NSString *urlString = @"appGoods/findGoodsDetailList.do";
    
//    NSDictionary *parameters = @{@"GoodsId":self.goodsBannerID};
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestGet parameters:_parameters prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        LLULog(@"successs");

        for (NSDictionary *dict in responseObject) {
            
            LLuGoodsDetailIMageAndText *goodsDetailImgText = [LLuGoodsDetailIMageAndText mj_objectWithKeyValues:dict];
            
            [self.goodsDetailImgAndTextList addObject:goodsDetailImgText];
            
            self.imageAndTextViewH += 30;
        }
        [self.scrollView addSubview:self.goodsDetailIMageAndTextView];
        self.goodsDetailIMageAndTextView.goodsDetailItems = weakSelf.goodsDetailImgAndTextList;

//        NSLog(@"imageAndTextViewH===%lf", self.imageAndTextViewH);
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}

- (void)viewDidLayoutSubviews {

    [super viewDidLayoutSubviews];
    WS(weakSelf);
 
    self.bannerView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 200);
    
    [_toolBar mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.bottom.right.equalTo(weakSelf.view);
        make.height.equalTo(@49);
    }];

    CGFloat scrollViewSizeH = _goodsDetailIMageAndTextView.height + _imageViewH + _bannerView.height + _goodsDetailView.height + _toolBar.height + _goodsDetailBrandView.height;
    
//    NSLog(@"scrollViewSizeH====%lf", scrollViewSizeH);
    _scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, scrollViewSizeH + 49);
    
//    [_contentView mas_remakeConstraints:^(MASConstraintMaker *make) {
//        
//        make.top.equalTo(weakSelf.view);
//        make.height.equalTo(_scrollView.contentSize.height);
//    }];

}

- (void)bannerView:(LLuBannerView *)bannerView imageDidClickWithIndex:(NSInteger)imageIndex {
    
    
}

- (void)SameBrandGoods {
    
//    LLULog(@"查看同类品牌商品");
    LLuShopGoodsViewController *shopGoodsVC = [[LLuShopGoodsViewController alloc] init];
    shopGoodsVC.ShopId = self.goodsDetailBrandView.goodsDetail.ShopId;
    shopGoodsVC.title = self.goodsDetailBrandView.goodsDetail.BrandCNName;
    
    NSDictionary * parameters = @{
                              @"url" : @"appShop/appShopGoodsList.do",
                              @"IDType" : @"ShopId",
                              @"ID" : self.goodsDetailBrandView.goodsDetail.ShopId
                              };
    shopGoodsVC.parameters = [NSMutableDictionary dictionaryWithDictionary:parameters];
    UINavigationController *Nav = [[UINavigationController alloc] initWithRootViewController:shopGoodsVC];
    
    [self presentViewController:Nav animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
