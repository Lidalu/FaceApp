//
//  LLuTabBarViewController.m
//  有面儿
//
//  Created by ma c on 16/4/5.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuTabBarViewController.h"
#import "ControllersModel.h"

@interface LLuTabBarViewController ()

@property (nonatomic, strong) NSArray *controllersList;

@property (nonatomic, strong) NSMutableArray *controllers;

@end

@implementation LLuTabBarViewController

#pragma mark - getter and setter

- (NSArray *)controllersList {
    
    if (!_controllersList) {
        
        _controllersList = [ControllersModel controllersList];
    }
    return _controllersList;
}

- (NSMutableArray *)controllers {
    
    if (!_controllers) {
        
        _controllers = [NSMutableArray array];
    }
    return _controllers;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBar.translucent = NO;
    [self setUpChildViewController];
}

/**
 *  添加子控制器，通过plist转模型，复用性高
 */
- (void)setUpChildViewController{
    
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    attrs[NSForegroundColorAttributeName] = [UIColor grayColor];
    
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSFontAttributeName] = attrs[NSFontAttributeName];
    selectedAttrs[NSForegroundColorAttributeName] = [UIColor colorWithRed:0.2078 green:0.6863 blue:0.9294 alpha:1.0];
    
    UITabBarItem *item = [UITabBarItem appearance];
    [item setTitleTextAttributes:attrs forState:UIControlStateNormal];
    [item setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
    
    for (NSInteger i = 0; i < self.controllersList.count; i++) {
        
        ControllersModel *controllerModel = self.controllersList[i];
        NSString *tabBartitle = controllerModel.tabBartitle;
        NSString *tabBarSelectedImageName = controllerModel.ControllerTabbarIcon_Selected;
        NSString *tabBarNormalImageName = controllerModel.ControllerTabbarIcon_Normal;
        NSString *rigthBarItemImageName = controllerModel.rightBarItemIconName;
        NSString *leftBarItemImageName = controllerModel.leftBarItemIconName;
        NSString *viewControllerName = controllerModel.controllerName;
        
        UINavigationController *Nav = [[UINavigationController alloc] initWithRootViewController:[[NSClassFromString(viewControllerName) alloc] init]];
        //设置导航栏的半透明效果
        Nav.navigationBar.translucent = NO;
        /**
         *  设置navigation的线
         */
        [Nav.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];

        [Nav.navigationBar setShadowImage:[[UIImage alloc] init]];
        
        [self setupOneChildViewController:Nav
                    tabBarNormalImageName:tabBarNormalImageName
                  tabBarSelectedImageName:tabBarSelectedImageName
                     leftBarItemImageName:leftBarItemImageName
                    rigthBarItemImageName:rigthBarItemImageName
                              tabBartitle:tabBartitle];
        
        
        [self.controllers addObject:Nav];
    }
    
    self.viewControllers = self.controllers;
}

/**
 *  添加一个子控制器
 *
 *  @param viewController          viewController
 *  @param tabBarNormalImageName   tabBar的Normal图片
 *  @param tabBarSelectedImageName tabBar的选中图片
 *  @param leftBarItemImageName    ViewController导航条的左buttonItem
 *  @param rigthBarItemImageName   ViewController导航条的右buttonItem
 *  @param title                   tabBar的标题
 */
- (void)setupOneChildViewController:(UIViewController *)viewController
              tabBarNormalImageName:(NSString *)tabBarNormalImageName
            tabBarSelectedImageName:(NSString *)tabBarSelectedImageName
               leftBarItemImageName:(NSString *)leftBarItemImageName
              rigthBarItemImageName:(NSString *)rigthBarItemImageName
                        tabBartitle:(NSString *)tabBartitle{
    
    
    //tabBarNormalImage
    UIImage *tabBarNormalImage = [UIImage imageNamed:tabBarNormalImageName];
    tabBarNormalImage = [tabBarNormalImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    //tabBarSelectedImage
    UIImage *tabBarSelectedImage = [UIImage imageNamed:tabBarSelectedImageName];
    tabBarSelectedImage = [tabBarSelectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    viewController.tabBarItem.image = tabBarNormalImage;
    viewController.tabBarItem.selectedImage = tabBarSelectedImage;
    
    viewController.tabBarItem.title = tabBartitle;
    viewController.tabBarController.edgesForExtendedLayout = UIRectEdgeNone;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
