//
//  LLuMineHeaderView.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuMineHeaderView.h"

@implementation LLuMineHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor colorWithRed:0.3647 green:0.7529 blue:0.902 alpha:1.0];
        [self addSubview:self.loginBtn];
        [self addSubview:self.registerBtn];
    }
    
    return self;
}

- (void)layoutSubviews {
    
    WS(weakSelf);
    [super layoutSubviews];
    [_loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.mas_left).offset(107);
        make.centerY.equalTo(weakSelf.mas_centerY);
        make.width.equalTo(@53);
        make.height.equalTo(30);
    }];
    
    [_registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        
        
        make.right.equalTo(weakSelf.mas_right).offset(-107);
        make.centerY.equalTo(weakSelf.mas_centerY);
        make.width.equalTo(@53);
        make.height.equalTo(30);

    }];
    
}

- (UIButton *)loginBtn {
    
    if (!_loginBtn) {
        
        _loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//        _loginBtn.backgroundColor = [UIColor redColor];
        [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
        [_loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _loginBtn.titleLabel.font = [UIFont systemFontOfSize:20];
        [_loginBtn sizeToFit];
    }
    return _loginBtn;
}

- (UIButton *)registerBtn {
    
    if (!_registerBtn) {
        
        _registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//        _registerBtn.backgroundColor = [UIColor greenColor];
        [_registerBtn setTitle:@"注册" forState:UIControlStateNormal];
        [_registerBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _registerBtn.titleLabel.font = [UIFont systemFontOfSize:20];
        [_registerBtn sizeToFit];
    }
    return _registerBtn;
}

@end
