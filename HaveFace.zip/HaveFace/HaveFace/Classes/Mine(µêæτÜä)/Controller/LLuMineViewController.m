//
//  LLuMineViewController.m
//  有面儿
//
//  Created by ma c on 16/4/5.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuMineViewController.h"
#import "LLuMineHeaderView.h"
#import "LLuMineLoginModel.h"
#import "LLuMineRegisterModel.h"
#import "LLuLoginViewController.h"
#import "LLuRegisterViewController.h"

static NSString *cellID = @"cellID";
@interface LLuMineViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) LLuMineHeaderView *headerView;

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSArray *loginModelList;

@property (nonatomic, strong) NSArray *registerModelList;

@property (nonatomic, assign) CGFloat tableViewH;

@end

@implementation LLuMineViewController

- (NSArray *)loginModelList {
    
    if (!_loginModelList) {
        
        _loginModelList = [LLuMineLoginModel loginModelsList];
    }
    return _loginModelList;
}

- (NSArray *)registerModelList {
    
    if (!_registerModelList) {
        
        _registerModelList = [LLuMineRegisterModel registerModelsList];
    }
    return _registerModelList;
}

- (LLuMineHeaderView *)headerView {
    
    if (!_headerView) {
        
        _headerView = [[LLuMineHeaderView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 125)];
        [_headerView.loginBtn addTarget:self action:@selector(userLogin) forControlEvents:UIControlEventTouchUpInside];
        [_headerView.registerBtn addTarget:self action:@selector(userRegister) forControlEvents:UIControlEventTouchUpInside];

    }
    return _headerView;
}

- (UITableView *)tableView {
    
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 160, SCREEN_WIDTH, _tableViewH) style:UITableViewStylePlain];
        _tableView.backgroundColor = [UIColor colorWithRed:0.949 green:0.949 blue:0.949 alpha:1.0];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.scrollEnabled = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    }
    return _tableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.loginModelList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellID];
    }
    LLuMineLoginModel *loginModel = self.loginModelList[indexPath.row];
    cell.imageView.image = [UIImage imageNamed:loginModel.icon];
    cell.textLabel.text = loginModel.title;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    UIView *backView = [[UIView alloc] initWithFrame:cell.contentView.bounds];
    backView.backgroundColor = [UIColor clearColor];
    cell.selectedBackgroundView = backView;
    if (loginModel.accessoryString.length > 0) {
        
        cell.detailTextLabel.text = loginModel.accessoryString;
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}


- (void)initUI {
    
    self.title = @"我的";
    self.view.backgroundColor = [UIColor colorWithRed:0.949 green:0.949 blue:0.949 alpha:1.0];
    [self.view addSubview:self.headerView];
    self.tableViewH = self.loginModelList.count * 44;
    [self.view addSubview:self.tableView];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self initUI];
    
    [self loadData];
}

- (void)loadData {
    
    [self memberRegister];
}

- (void)memberRegister {
    
    NSString *urlString = @"appMember/appRegistration.do";
    //    WS(weakSelf);
    NSDictionary *parameters = @{@"LoginName":@"15712345678",
                                 @"Lpassword":@"daaad"};
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestPost parameters:parameters prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        LLULog(@"successs");
        
        LLULog(@"result%@", responseObject);
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}

- (void)userLogin {
    
    LLuLoginViewController *loginVc = [[LLuLoginViewController alloc] init];
    UINavigationController *loginNav = [[UINavigationController alloc] initWithRootViewController:loginVc];
    [self presentViewController:loginNav animated:YES completion:nil];
}

- (void)userRegister {
    
    LLuRegisterViewController *registerVc = [[LLuRegisterViewController alloc] init];
    UINavigationController *registerNav = [[UINavigationController alloc] initWithRootViewController:registerVc];
    [self presentViewController:registerNav animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
