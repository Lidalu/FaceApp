//
//  LLuLoginViewController.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuLoginViewController.h"

@interface LLuLoginViewController () <UITextFieldDelegate>

@property (nonatomic, strong) UIBarButtonItem *backItem;

@property (nonatomic, strong) UIView *inputView;

@property (nonatomic, strong) UITextField *phoneTextField;

@property (nonatomic, strong) UILabel *lineLabel;

@property (nonatomic, strong) UITextField *passwdTextField;

@property (nonatomic, strong) UIButton *loginBtn;

@property (nonatomic, strong) UIButton *registerBtn;

@end

@implementation LLuLoginViewController

- (UIBarButtonItem *)backItem {
    
    if (!_backItem) {
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, 30, 30);
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(backToHome) forControlEvents:UIControlEventTouchUpInside];
        _backItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    }
    return _backItem;
}

- (UIView *)inputView {
    
    if (!_inputView) {
        
        _inputView = [[UIView alloc] initWithFrame:CGRectMake(0, 15, SCREEN_WIDTH, 89)];
        _inputView.backgroundColor = [UIColor whiteColor];
        [_inputView addSubview:self.phoneTextField];
        [_inputView addSubview:self.lineLabel];
        [_inputView addSubview:self.passwdTextField];
    }
    return _inputView;
}

- (UITextField *)phoneTextField {
    
    if (!_phoneTextField) {
        
        _phoneTextField = [[UITextField alloc] init];
        _phoneTextField.placeholder = @"请输入手机号码";
    }
    return _phoneTextField;
}

- (UILabel *)lineLabel {
    
    if (!_lineLabel) {
        
        _lineLabel = [[UILabel alloc] init];
        _lineLabel.backgroundColor = [UIColor colorWithRed:0.7412 green:0.7333 blue:0.7569 alpha:1.0];
    }
    return _lineLabel;
}

- (UITextField *)passwdTextField {
    
    if (!_passwdTextField) {
        
        _passwdTextField = [[UITextField alloc] init];
        _passwdTextField.placeholder = @"请输入密码";
    }
    return _passwdTextField;
}

- (UIButton *)loginBtn {
    
    if (!_loginBtn) {
        
        _loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_loginBtn setImage:[UIImage imageNamed:@"登录界面登录按钮"] forState:UIControlStateNormal];
        
    }
    return _loginBtn;
}

- (UIButton *)registerBtn {
    
    if (!_registerBtn) {
        
        _registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_registerBtn setTitle:@"免费注册" forState:UIControlStateNormal];
        [_registerBtn setTitleColor:[UIColor colorWithRed:0.0706 green:0.549 blue:0.7059 alpha:1.0] forState:UIControlStateNormal];
    }
    return _registerBtn;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"登录";
    self.view.backgroundColor = [UIColor colorWithRed:0.949 green:0.949 blue:0.949 alpha:1.0];
    //设置导航栏的半透明效果
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:0.9608 green:0.9608 blue:0.9608 alpha:1.0];
    self.navigationController.navigationBar.translucent = NO;
    
    self.navigationItem.leftBarButtonItem = self.backItem;
    [self.view addSubview:self.inputView];
    [self.view addSubview:self.loginBtn];
    [self.view addSubview:self.registerBtn];
}

- (void)backToHome {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    LLULog(@"PoP to Home");
}

- (void)viewDidLayoutSubviews {
    
    [super viewDidLayoutSubviews];
    
    WS(weakSelf);
    
    [_phoneTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.inputView.mas_left).offset(15);
        make.right.equalTo(weakSelf.inputView.mas_right).offset(-15);
        make.top.equalTo(weakSelf.inputView.mas_top);
        make.height.equalTo(@44);
    }];
    
    [_lineLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.inputView.mas_left).offset(15);
        make.right.equalTo(weakSelf.inputView.mas_right).offset(-15);
        make.top.equalTo(weakSelf.phoneTextField.mas_bottom);
        make.height.equalTo(@1);
    }];
    
    [_passwdTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.inputView.mas_left).offset(15);
        make.right.equalTo(weakSelf.inputView.mas_right).offset(-15);
        make.top.equalTo(weakSelf.lineLabel.mas_bottom);
        make.height.equalTo(@44);
    }];
    
    [_loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.view.mas_left).offset(16);
        make.right.equalTo(weakSelf.view.mas_right).offset(-16);
        make.top.equalTo(weakSelf.passwdTextField.mas_bottom).offset(15);
        make.height.equalTo(@35);
        
    }];
    
    [_registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.loginBtn.mas_bottom).offset(18);
        make.right.equalTo(weakSelf.view.mas_right).offset(-16);
    }];
}

@end
