//
//  LLuRegisterViewController.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuRegisterViewController.h"
#import "LLuMineViewController.h"

@interface LLuRegisterViewController () <UITextFieldDelegate>

@property (nonatomic, strong) UIBarButtonItem *backItem;

@property (nonatomic, strong) UILabel *placeholderLabel;

@property (nonatomic, strong) UIView *inputView;

@property (nonatomic, strong) UITextField *phoneTextField;

@property (nonatomic, strong) UILabel *lineLabel;

@property (nonatomic, strong) UITextField *passwdTextField;

@property (nonatomic, strong) UIButton *nextStepBtn;

@property (nonatomic, strong) UIButton *loginBtn;

@property (nonatomic, strong) NSMutableDictionary *parameters;

@end

@implementation LLuRegisterViewController

- (UIBarButtonItem *)backItem {
    
    if (!_backItem) {
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(0, 0, 30, 30);
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"详情界面返回按钮"] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(backToHome) forControlEvents:UIControlEventTouchUpInside];
        _backItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    }
    return _backItem;
}

- (UILabel *)placeholderLabel {
    
    if (!_placeholderLabel) {
        
        _placeholderLabel = [[UILabel alloc] init];
        
        _placeholderLabel.backgroundColor = [UIColor colorWithRed:0.949 green:0.949 blue:0.949 alpha:1.0];
        _placeholderLabel.text = @"请输入手机号码注册";
        _placeholderLabel.textColor = [UIColor darkGrayColor];
        _placeholderLabel.adjustsFontSizeToFitWidth = YES;
        [_placeholderLabel sizeToFit];
    }
    return _placeholderLabel;
}

- (UIView *)inputView {
    
    if (!_inputView) {
        
        _inputView = [[UIView alloc] initWithFrame:CGRectMake(0, 35, SCREEN_WIDTH, 89)];
        _inputView.backgroundColor = [UIColor whiteColor];
        [_inputView addSubview:self.phoneTextField];
        [_inputView addSubview:self.lineLabel];
        [_inputView addSubview:self.passwdTextField];
    }
    return _inputView;
}

- (UITextField *)phoneTextField {
    
    if (!_phoneTextField) {
        
        _phoneTextField = [[UITextField alloc] init];
        _phoneTextField.placeholder = @"请输入手机号码";
        _phoneTextField.delegate = self;
    }
    return _phoneTextField;
}

- (UILabel *)lineLabel {
    
    if (!_lineLabel) {
        
        _lineLabel = [[UILabel alloc] init];
        _lineLabel.backgroundColor = [UIColor colorWithRed:0.7412 green:0.7333 blue:0.7569 alpha:1.0];
    }
    return _lineLabel;
}

- (UITextField *)passwdTextField {
    
    if (!_passwdTextField) {
        
        _passwdTextField = [[UITextField alloc] init];
        _passwdTextField.placeholder = @"请输入密码";
        _passwdTextField.delegate = self;
    }
    return _passwdTextField;
}

- (UIButton *)nextStepBtn {
    
    if (!_nextStepBtn) {
        
        _nextStepBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_nextStepBtn setImage:[UIImage imageNamed:@"注册界面下一步按钮"] forState:UIControlStateNormal];
    }
    return _nextStepBtn;
}

- (UIButton *)loginBtn {
    
    if (!_loginBtn) {
        
        _loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_loginBtn setTitle:@"去登录" forState:UIControlStateNormal];
        [_loginBtn setTitleColor:[UIColor colorWithRed:0.0824 green:0.651 blue:0.949 alpha:1.0] forState:UIControlStateNormal];
        [_loginBtn.titleLabel sizeToFit];
    }
    return _loginBtn;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self initUI];
//    [self loadData];
}

- (void)initUI {
    
    self.title = @"注册";
    self.view.backgroundColor = [UIColor colorWithRed:0.949 green:0.949 blue:0.949 alpha:1.0];
    //设置导航栏的半透明效果
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:0.9608 green:0.9608 blue:0.9608 alpha:1.0];
    self.navigationController.navigationBar.translucent = NO;
    
    self.navigationItem.leftBarButtonItem = self.backItem;
    [self.view addSubview:self.placeholderLabel];
    [self.view addSubview:self.inputView];
    [self.view addSubview:self.nextStepBtn];
    [self.view addSubview:self.loginBtn];
}

- (void)loadData {
    
    [self memberRegister];
}

- (void)memberRegister {
    
    NSString *urlString = @"appMember/appRegistration.do";
    //    WS(weakSelf);
//    NSDictionary *parameters = @{@"LoginName":@"",
//                                 @"Lpassword":@""};
    
    LLULog(@"%@", self.parameters);
    [[HttpClient defaultClient] requestWithPath:urlString method:HttpRequestGet parameters:_parameters prepareExecute:^{
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        LLULog(@"successs");
        
        LLULog(@"result%@", responseObject);
        
        if ([responseObject[0] isEqualToString:@"codeError"]) {
            
        } else {
            
            
        }
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        LLULog(@"请求失败");
        LLULog(@"error--->%@", error);
    }];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    if (textField == self.phoneTextField) {
        
        [self setValue:textField.text forKey:@"LoginName"];
    } else {
        
        [self setValue:textField.text forKey:@"Lpassword"];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if (self.phoneTextField == textField) {
        [self.passwdTextField becomeFirstResponder];
    } else if (self.passwdTextField == textField) {
        [self loadData];
    }
    else {
        [textField becomeFirstResponder];
    }
    
    return YES;
}

- (void)viewDidLayoutSubviews {
    
    [super viewDidLayoutSubviews];
    WS(weakSelf);
    
    [_placeholderLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.view.mas_left).offset(15);
        make.top.equalTo(weakSelf.view.mas_top).offset(10);
        make.height.equalTo(@14);
    }];
    
    [_phoneTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.inputView.mas_left).offset(15);
        make.right.equalTo(weakSelf.inputView.mas_right).offset(-15);
        make.top.equalTo(weakSelf.inputView.mas_top);
        make.height.equalTo(@44);
    }];
    
    [_lineLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.inputView.mas_left).offset(15);
        make.right.equalTo(weakSelf.inputView.mas_right).offset(-15);
        make.top.equalTo(weakSelf.phoneTextField.mas_bottom);
        make.height.equalTo(@1);
    }];
    
    [_passwdTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.inputView.mas_left).offset(15);
        make.right.equalTo(weakSelf.inputView.mas_right).offset(-15);
        make.top.equalTo(weakSelf.lineLabel.mas_bottom);
        make.height.equalTo(@44);
    }];
    
    [_nextStepBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(weakSelf.view.mas_left).offset(16);
        make.right.equalTo(weakSelf.view.mas_right).offset(-16);
        make.top.equalTo(weakSelf.passwdTextField.mas_bottom).offset(15);
        make.height.equalTo(@35);
    }];
    
    [_loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.nextStepBtn.mas_bottom).offset(23);
        make.right.equalTo(weakSelf.view.mas_right).offset(-15);

    }];
}

- (void)backToHome {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    LLULog(@"PoP to Home");
}


@end
