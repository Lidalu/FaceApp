//
//  LLuMineRegisterModel.h
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LLuMineRegisterModel : NSObject

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *accessoryString;

- (instancetype)initWithDict:(NSDictionary *)dict;

+ (instancetype)registerModelWithDict:(NSDictionary *)dict;

+ (NSArray *)registerModelsList;
@end
