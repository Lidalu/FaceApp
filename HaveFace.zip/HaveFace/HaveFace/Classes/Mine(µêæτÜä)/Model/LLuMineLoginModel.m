//
//  LLuMineLoginModel.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuMineLoginModel.h"

@implementation LLuMineLoginModel

- (instancetype)initWithDict:(NSDictionary *)dict {
    
    if (self = [super init]) {
        
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)loginModelWithDict:(NSDictionary *)dict {
    
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)loginModelsList {
    
    //加载plist
    NSString *path = [[NSBundle mainBundle] pathForResource:@"LLuMineLoginModel" ofType:@"plist"];
    NSArray *dictArray = [NSArray arrayWithContentsOfFile:path];
    
    //字典转模型
    NSMutableArray *tmpArray = [NSMutableArray array];
    for (NSDictionary *dict in dictArray) {
        
        LLuMineLoginModel *loginModel = [LLuMineLoginModel loginModelWithDict:dict];
        [tmpArray addObject:loginModel];
    }
    return tmpArray;
}

@end
