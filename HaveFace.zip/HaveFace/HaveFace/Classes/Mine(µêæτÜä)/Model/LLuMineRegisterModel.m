//
//  LLuMineRegisterModel.m
//  Face_App
//
//  Created by ma c on 16/4/13.
//  Copyright © 2016年 lu. All rights reserved.
//

#import "LLuMineRegisterModel.h"

@implementation LLuMineRegisterModel

- (instancetype)initWithDict:(NSDictionary *)dict {
    
    if (self = [super init]) {
        
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)registerModelWithDict:(NSDictionary *)dict {
    
    return [[self alloc] initWithDict:dict];
}

+ (NSArray *)registerModelsList {
    
    //加载plist
    NSString *path = [[NSBundle mainBundle] pathForResource:@"LLuMineLoginModel" ofType:@"plist"];
    NSArray *dictArray = [NSArray arrayWithContentsOfFile:path];
    
    //字典转模型
    NSMutableArray *tmpArray = [NSMutableArray array];
    for (NSDictionary *dict in dictArray) {
        
        LLuMineRegisterModel *registerModel = [LLuMineRegisterModel registerModelWithDict:dict];
        [tmpArray addObject:registerModel];
    }
    return tmpArray;
}

@end
