//
//  UIBarButtonItem+LLuExtension.h
//  高仿百思不得姐
//
//  Created by ma c on 3/29/16.
//  Copyright © 2016 lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (LLuExtension)

+ (instancetype)itemWithNormalImage:(NSString *)normalImageName highlightedImage:(NSString *)highlightedImageName target:(id)target action:(SEL)action;
@end
