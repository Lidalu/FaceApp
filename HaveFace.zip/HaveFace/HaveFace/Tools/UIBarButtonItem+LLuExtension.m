//
//  UIBarButtonItem+LLuExtension.m
//  高仿百思不得姐
//
//  Created by ma c on 3/29/16.
//  Copyright © 2016 lu. All rights reserved.
//

#import "UIBarButtonItem+LLuExtension.h"

@implementation UIBarButtonItem (LLuExtension)

+ (instancetype)itemWithNormalImage:(NSString *)normalImageName highlightedImage:(NSString *)highlightedImageName target:(id)target action:(SEL)action {
    
    UIButton *customButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [customButton setBackgroundImage:[UIImage imageNamed:normalImageName] forState:UIControlStateNormal];
    [customButton setBackgroundImage:[UIImage imageNamed:highlightedImageName] forState:UIControlStateHighlighted];
    
    customButton.size = customButton.currentBackgroundImage.size;
    [customButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    return [[self alloc] initWithCustomView:customButton];
}

@end
